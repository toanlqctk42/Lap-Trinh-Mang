function isBlank(str) {
    return str == null || str == '' || str == 'undefined' || str == undefined;
}

function getSid() {
    var href = window.location.href;
    var params = extractParams(takeFromByDelimiter(href, "?"));
    //window.alert(params);
    //return params.sid;

    return params.sid;
}

function checkAuthenticationAtIndexPage() {
    var sid = getSid();
    //var sid = 0;
    if (!isBlank(sid)) {
        console.log('User is authenticated, sid: ', sid);
        window.location.href = "chat.html?sid=" + sid;
    }
}

function checkAuthenticationAtChatPage() {
    var sid = getSid();
    //var sid = 200;
    
    if (isBlank(sid)) {
        console.log('User is not authenticated to go to this page');
        window.location.href = "index.html";
    } else {
        
        // verify sid is correct, if not return index.html
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (xhttp.readyState == 4 && xhttp.status == 200) {
                         
                var res = JSON.parse(xhttp.responseText);
                
                
                for(var i = 0; i < res.length; i++){
                    if(sid == res[i].iD){
                        document.getElementById("username").innerText = res[i].userName;
                    }
                }
                var select = document.getElementById('userList');
                
                var OnlineList = ' ';
                
                for(var i = 0; i < res.length; i++){
                    if(sid != res[i].iD){
                        var opt = document.createElement('option');
                        opt.value = res[i].iD;
                        opt.innerHTML = res[i].userName + "    -    " + res[i].status;
                        select.appendChild(opt);
                    }
                }

            } else if (xhttp.status == 401) { // unauthorized
                window.location.href = "index.html";
            }
        };
        xhttp.open("POST", "https://localhost:8888/initChat", true);
        xhttp.setRequestHeader('Content-type',
                'application/x-www-form-urlencoded');
        var params = "sid=" + sid;
        xhttp.send(params);
    }
}

function takeFromByDelimiter(location, delimiter) {
    var parts = location.split(delimiter);
    return parts[parts.length - 1];
}

function extractParams(query) {

    var result = {};

    query.split("&").forEach(function (part) {
        var item = part.split("=");
        result[item[0]] = decodeURIComponent(item[1]);
    });
    return result;

}

function logout() {
    var sid = getSid();
    if (isBlank(sid)) {
        console.log('User is valid to logout');
        window.location.href = "index.html";
    } else {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (xhttp.readyState == 4 && xhttp.status == 200) {
                //window.alert("1231");
                console.log(xhttp.responseText);
                window.location.href = "index.html";
            }
        };
        xhttp.open("POST", "https://localhost:8888/logout", true);
        xhttp.setRequestHeader('Content-type',
                'application/x-www-form-urlencoded');
        var params = "sid=" + sid;
        xhttp.send(params);
    }
}

window.setInterval(function () {
    refreshListOnlinePage(); // calling every 3 seconds
    refreshChatPage();
    var elem = document.getElementById('chatLog');
    if (elem != null) {
        elem.scrollTop = elem.scrollHeight;
    }
    
}, 3000);

function refreshListOnlinePage() {
    var sid = getSid();
    if (isBlank(sid)) {
        return;
    } else {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (xhttp.readyState == 4 && xhttp.status == 200) {
                console.log(xhttp.responseText);
                var res = JSON.parse(xhttp.responseText);
                
                var select = document.getElementById('userList');
                
                select.innerHTML = '';
                
                for(var i = 0; i < res.length; i++){
                    if(sid != res[i].iD){
                        var opt = document.createElement('option');
                        opt.value = res[i].iD;
                        opt.innerHTML = res[i].userName + "    -    " + res[i].status;
                        select.appendChild(opt);
                    }
                }
       

            } else if (xhttp.status == 401) { // unauthorized
                window.location.href = "index.html";
            }
        };
        xhttp.open("POST", "https://localhost:8888/refreshListOnline", true);
        xhttp.setRequestHeader('Content-type',
                'application/x-www-form-urlencoded');
        var params = "sid=" + sid;
        xhttp.send(params);
    }
}

function refreshChatPage() {
    var sid = getSid();
    if (isBlank(sid)) {
        return;
    } else {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (xhttp.readyState == 4 && xhttp.status == 200) {
                console.log(xhttp.responseText);
                var res = JSON.parse(xhttp.responseText);
                
                var select = document.getElementById('chatLog');
                
                select.innerHTML = '';
                
                for(var i = 0; i < res.length; i++){
                    if(sid != res[i].iD){
                        select.innerHTML += res[i].userName + ": "  + res[i].message;
                        select.innerHTML += "</br>";
                    }
                }
               
            } else if (xhttp.status == 401) { // unauthorized
                window.location.href = "index.html";
            }
        };
        xhttp.open("POST", "https://localhost:8888/refreshChatPage", true);
        xhttp.setRequestHeader('Content-type',
                'application/x-www-form-urlencoded');
        var params = "sid=" + sid;
        xhttp.send(params);
    }
}

function sendChatAll() {
    var sid = getSid();
    if (isBlank(sid)) {
        return;
    } else {
        var message = document.getElementById("chatWindow").value;
        if (isBlank(message)) {
            alert('You should enter message to send!');
            return;
        }
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function () {
            if (xhttp.readyState == 4 && xhttp.status == 200) {
                //window.alert(xhttp.responseText);
                
                var select = document.getElementById('chatWindow');
                
                select.value = '';
                
                //document.getElementById("chatWindow").innerHTML = '';
            } else if (xhttp.status == 401) { // unauthorized
                window.location.href = "index.html";
            }
        };
        xhttp.open("POST", "https://localhost:8888/sendChatAll", true);

        xhttp.setRequestHeader('Content-type',
                'application/x-www-form-urlencoded');
        var params = "sid=" + sid + "&message=" + message.replace(/\n|\r\n|\r/g, "<br/>\r\n");
        xhttp.send(params);
    }
}


