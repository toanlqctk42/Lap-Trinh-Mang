function login() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    if (isBlank(username) || isBlank(password)) {
        document.getElementById("error").innerText = "Username Or Password should not be blank.";
        return;
    }
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {//xhttp.readyState == 4 || xhttp.status == 200
        //window.alert(xhttp.status);
        if (xhttp.readyState == 4 && xhttp.status == 200) {
			
            var res = xhttp.responseText;
           //window.alert(res);
            if (isServerBusy(res)) {
                document.getElementById("error").innerText = "Server is busy. Try later";
            } else {
                var sid = res;
                document.getElementById("error").innerText = "";
                window.location.href = "webchat.html?sid=" + sid;
            }
        } else if (xhttp.status == 401) { // unauthorized
            var res = xhttp.responseText;
            //window.alert(res);
            if (isLoginFailed(res)) {
                document.getElementById("error").innerText = "Username Or Password is not correct.";
            } else {
                document.getElementById("error").innerText = res;
            }
        }
    };
    xhttp.open("POST", "https://localhost:8888/login", true);
    xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    var params = "username=" + username + "&pwd=" + password;
    xhttp.send(params);
}

function isServerBusy(res) {
    return res.indexOf('SERVER_BUSY') != -1;
}

function isLoginFailed(res) {
    return res.indexOf('LOGIN_FAILED') != -1;
}

function isBlank(str) {
    return str == null || str == '' || str == 'undefined' || str == undefined;
}

function getSid() {
    var href = window.location.href;
    var params = extractParams(takeFromByDelimiter(href, "?"));
    //window.alert(params);
    //return params.sid;

    return params.sid;
}

function checkAuthenticationAtIndexPage() {
    var sid = getSid();
    //var sid = 0;
    if (!isBlank(sid)) {
        console.log('User is authenticated, sid: ', sid);
        window.location.href = "webchat.html?sid=" + sid;
    }
}

function takeFromByDelimiter(location, delimiter) {
    var parts = location.split(delimiter);
    return parts[parts.length - 1];
}

function extractParams(query) {

    var result = {};

    query.split("&").forEach(function (part) {
        var item = part.split("=");
        result[item[0]] = decodeURIComponent(item[1]);
    });
    return result;

}
   

window.setInterval(function () {
  
}, 3000)
