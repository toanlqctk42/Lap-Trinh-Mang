/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utility;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;

/**
 *
 * @author VTB
 */
public class WebChatLog {
    /**
     *
     */
    public String userName;
    
    /**
     *
     */
    public String message;

    public WebChatLog() {
    }

    public WebChatLog(String userName, String message) {
        this.userName = userName;
        this.message = message;
    }
    
    public static String convertListToJson(List<WebChatLog> list) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        //objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        return objectMapper.writeValueAsString(list);
    }
}
