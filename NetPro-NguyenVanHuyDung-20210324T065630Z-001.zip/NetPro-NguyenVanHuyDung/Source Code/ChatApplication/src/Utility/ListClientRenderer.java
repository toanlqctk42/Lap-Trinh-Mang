/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utility;

import Test.Book;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.GridLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;
import javax.swing.border.EmptyBorder;

/**
 *
 * @author VTB
 */
public class ListClientRenderer extends JPanel implements ListCellRenderer<Client> {

    private final JLabel lbIcon = new JLabel();
    private final JLabel lbUserName = new JLabel();
    private final JLabel lbStatus = new JLabel();
    private final JPanel panelText;
    private final JPanel panelIcon;

    @Override
    public Component getListCellRendererComponent(JList<? extends Client> list, Client client, int index, boolean isSelected, boolean cellHasFocus) {
        list.setOpaque(true);
        list.setBackground(Color.WHITE);
        if (client.status.compareTo(ClientStatus.online) == 0) {
            lbIcon.setIcon(new ImageIcon(getClass().getResource(
                    "../img/online.png")));
        } else {
            lbIcon.setIcon(new ImageIcon(getClass().getResource(
                    "../img/offline.png")));
        }
        lbUserName.setText(client.userName);
        lbStatus.setText(client.status.toString());
        lbStatus.setForeground(Color.blue);

        // set Opaque to change background color of JLabel
        lbUserName.setOpaque(true);
        lbStatus.setOpaque(true);
        lbIcon.setOpaque(true);

        // when select item
        if (isSelected) {
            lbUserName.setBackground(list.getSelectionBackground());
            lbStatus.setBackground(list.getSelectionBackground());
            lbIcon.setBackground(list.getSelectionBackground());
            setBackground(list.getSelectionBackground());
            setBackground(list.getSelectionBackground());
            //panelIcon.setOpaque(true);
        } else { // when don't select
            lbUserName.setBackground(list.getBackground());
            lbStatus.setBackground(list.getBackground());
            lbIcon.setBackground(list.getBackground());
            setBackground(list.getBackground());
            panelIcon.setBackground(list.getBackground());
            panelIcon.setOpaque(true);
        }
        return this;
    }

    public ListClientRenderer() {
        setLayout(new BorderLayout(5, 5));

        panelText = new JPanel(new GridLayout(0, 1));
        panelText.add(lbUserName);
        panelText.add(lbStatus);

        panelIcon = new JPanel();
        panelIcon.setBorder(new EmptyBorder(5, 5, 5, 5));
        panelIcon.add(lbIcon);

        add(panelIcon, BorderLayout.WEST);
        add(panelText, BorderLayout.CENTER);
    }

}
