/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utility;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.net.Socket;
import java.util.List;

/**
 *
 * @author VTB
 */
public class TransferFile {
    
    public int idSender;
    
    public int idReceiver;
    
    public String filename;
    
    public int fileSize;
    
    @JsonIgnore 
    public Socket socket;

    public TransferFile() {
    }
    
    public TransferFile(int idSender, int idReceiver) {
        this.idSender = idSender;
        this.idReceiver = idReceiver;
        this.filename = "";
        this.fileSize = 0;
        this.socket = null;
    }

    public TransferFile(int idSender, int idReceiver, String filename) {
        this.idSender = idSender;
        this.idReceiver = idReceiver;
        this.filename = filename;
        this.fileSize = 0;
        this.socket = null;
    }

    public TransferFile(int idSender, int idReceiver, String filename, int fileSize) {
        this.idSender = idSender;
        this.idReceiver = idReceiver;
        this.filename = filename;
        this.fileSize = fileSize;
        this.socket = null;
    }
    
    
    
    public String convertToJson() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        //objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        return objectMapper.writeValueAsString(this);
    }
    
    public static String convertListToJson(List<TransferFile> list) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        //objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        return objectMapper.writeValueAsString(list);
    }

    public static TransferFile convertToOject(String jsonString) throws JsonProcessingException, IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(jsonString, TransferFile.class);
    }
}
