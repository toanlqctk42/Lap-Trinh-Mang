/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utility;

import Utility.Encrytion.MD5;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import java.io.File;
import java.io.IOException;
import java.net.Socket;
import java.util.List;
//import java.util.List;

/**
 *
 * @author VTB
 */
public class Client {

    /**
     *
     */
    public int iD;

    /**
     *
     */
    public String userName;
    
    /**
     *
     */
    public String password;

    /**
     *
     */
    public ClientStatus status;
    
    /**
     *
     */
    @JsonIgnore 
    public Socket socket;
    
    @JsonIgnore 
    private String statusIconName;
    
    /**
     *
     */
    @JsonIgnore
    public String aesKey;
    
    /**
     *
     */
    @JsonIgnore
    public ClientTypes clientTypes;

    /**
     *
     */
    public Client() {
        userName = "";
        password = "";
        iD = 0;
        status = ClientStatus.offline;
        socket = null;
        aesKey = "";
        clientTypes = null;
    }

    /**
     *
     * @param iD
     * @param userName
     * @param pass
     * @param status
     */
    public Client(int iD, String userName, String pass, ClientStatus status) {
        this.iD = iD;
        this.userName = userName;
        this.status = status;
        this.password = pass;
        socket = null;
        aesKey = "";
        clientTypes = null;
    }

    @Override
    public String toString() {
        return this.userName;
    }

    /**
     *
     * @return
     */
    @JsonIgnore 
    public String getIconName() {
        return statusIconName;
    }

    /**
     *
     * @param iconName
     */
    @JsonIgnore 
    public void setIconName(String iconName) {
        this.statusIconName = iconName;
    }

    /**
     *
     * @param socket
     */
    public void setSocket(Socket socket) {
        this.socket = socket;
    }
    
    /**
     *
     * @return
     */
    public Socket getSocket() {
        return this.socket;
    }

    /**
     *
     * @return
     * @throws JsonProcessingException
     */
    public String convertToJson() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        //objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        return objectMapper.writeValueAsString(this);
    }
    
    /**
     *
     * @param list
     * @return
     * @throws JsonProcessingException
     */
    public static String convertListToJson(List<Client> list) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        //objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        return objectMapper.writeValueAsString(list);
    }

    /**
     *
     * @param jsonString
     * @return
     * @throws JsonProcessingException
     * @throws IOException
     */
    public static Client convertToOject(String jsonString) throws JsonProcessingException, IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(jsonString, Client.class);
    }

    /**
     *
     * @param jsonString
     * @return
     * @throws JsonProcessingException
     * @throws IOException
     */
    public static List<Client> convertToListOject(String jsonString) throws JsonProcessingException, IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        List<Client> resust = null;
        TypeReference<List<Client>> tRef = new TypeReference<List<Client>>() {
        };
        resust = objectMapper.readValue(jsonString, tRef);
        return resust;
    }

    /**
     *
     * @param list
     * @throws JsonProcessingException
     * @throws IOException
     */
    public static void writeToFile(List<Client> list) throws JsonProcessingException, IOException {
        for (int i = 0; i < list.size(); i++) {
            list.get(i).password = MD5.getMD5(list.get(i).password);
        }
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        objectMapper.writeValue(new File("data/listuser.json"), list);
        //objectMapper.writeValue(new BufferedWriter(new FileWriter("data/listuser.json", true)), list);
    }

    /**
     *
     * @param filename
     * @return
     * @throws JsonProcessingException
     * @throws IOException
     */
    public static List<Client> readFormFileToObject(String filename) throws JsonProcessingException, IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        List<Client> resust = null;
        TypeReference<List<Client>> tRef = new TypeReference<List<Client>>() {
        };
        //resust = objectMapper.readValue(new File("src/chatapplication/listuser.json"), tRef);
        resust = objectMapper.readValue(new File(filename), tRef);
        return resust;
    }
    
    /**
     *
     * @return
     * @throws JsonProcessingException
     * @throws IOException
     */
    public static List<Client> readFormFileToObject() throws JsonProcessingException, IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        List<Client> resust = null;
        TypeReference<List<Client>> tRef = new TypeReference<List<Client>>() {
        };
        //resust = objectMapper.readValue(new File("src/chatapplication/listuser.json"), tRef);
        resust = objectMapper.readValue(new File("data/listuser.json"), tRef);
        
        return resust;
    }

//    public static Client readFormFileToObject1() throws JsonProcessingException, IOException {
//        ObjectMapper objectMapper = new ObjectMapper();
//        Client resust = null;
//        resust = objectMapper.readValue(new File("src/chatapplication/listuser_1.json"), Client.class);
//        return resust;
//    }

    /**
     *
     * @param client
     * @param list
     * @return
     */
    public static boolean checkLogin(Client client, List<Client> list) {
        for (Client cli : list) {
            if (cli.userName.compareTo(client.userName) == 0
                    && cli.password.compareTo(client.password) == 0) {
                return true;
            }
        }
        return false;
    }

    /**
     *
     * @param client
     * @param list
     * @return
     */
    public static int checkLoginiD(Client client, List<Client> list) {
        for (Client cli : list) {
            if (cli.userName.compareTo(client.userName) == 0
                    && cli.password.compareTo(client.password) == 0) {
                if(cli.status.equals(ClientStatus.online))
                {
                    return -1;
                }
                return cli.iD;
            }
        }
        return 0;
        //return list.stream().anyMatch((cli) -> (cli.userName.compareTo(client.userName) == 0
        //        && cli.password.compareTo(client.password) == 0));
    }
}
