/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utility;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import java.io.IOException;

/**
 *
 * @author VTB
 */
public class Message {
    
    public int id;
    
    public int sender;
    
    public int reciever;
    
    public String content;

    public Message() {
    }

    public Message(int id, int sender, int reciever, String content) {
        this.id = id;
        this.sender = sender;
        this.reciever = reciever;
        this.content = content;
    }
    
    @Override
    public String toString() {
        return "";
    }
    
    
    public String convertToJson() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        //objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
        return objectMapper.writeValueAsString(this);
    }
    
    public static Message convertToOject(String jsonString) throws JsonProcessingException, IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(jsonString, Message.class);
    }
}
