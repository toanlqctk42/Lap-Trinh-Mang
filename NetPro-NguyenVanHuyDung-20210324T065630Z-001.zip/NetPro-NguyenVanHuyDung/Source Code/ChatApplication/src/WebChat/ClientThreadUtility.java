/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebChat;

import Server.Main;
import Utility.Client;
import Utility.ClientTypes;
import Utility.Encrytion.AESEncryption;
import Utility.Message;
import Utility.MessageType;
import java.io.DataOutputStream;
import java.net.Socket;

/**
 *
 * @author VTB
 */
public class ClientThreadUtility {

    public static void sendChatAllToChatApp(Main main, int sender, String content) throws Exception {
        for (Client client : main.clientList) {
           
            if (client.clientTypes != null) {
                if (client.clientTypes.equals(ClientTypes.application)) {
                    
                    if (client.iD != sender) {
                        try {
                            Socket tsoc2 = client.socket;
                            if (tsoc2 != null) {
                                DataOutputStream dos2 = new DataOutputStream(tsoc2.getOutputStream());
                                // "0" message for all
                                Message message = new Message(0, sender, 0, content);
                                dos2.writeUTF(AESEncryption.encryptTextUsingAES(MessageType.message.toString() + " " + "0" + " " + message.convertToJson(), client.aesKey));
                            }
                        } catch (Exception e) {
                            main.addMessage("[CHATALL-IOException]: " + e.getMessage());
                        }
                    }
                }
            }
        }
        main.addMessage("[CHATALL]: " + content);
    }
}
