package WebChat;

import Server.Main;
import Utility.WebChatLog;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;
import com.sun.net.httpserver.HttpServer;

public class SimpleHttpServer {

    public static int port;
    private HttpServer server;
    public static Main main;
    
    public static List<WebChatLog> listLog;
    
    

    public void Start(int port, Main main) {
        try {
            this.main = main;
            this.port = port;
            server = HttpServer.create(new InetSocketAddress(port), 0);
            System.out.println("server started at " + port);
            
            listLog = new ArrayList<>();
            
            ////////////////////////////////////////////////////////
            //Code Example
            server.createContext("/", new Handlers.RootHandler());
            server.createContext("/echoHeader", new Handlers.EchoHeaderHandler());
            server.createContext("/echoGet", new Handlers.EchoGetHandler());
            server.createContext("/echoPost", new Handlers.EchoPostHandler());
            ////////////////////////////////////////////////////////
            //Login
            server.createContext("/login", new Handlers.loginPostHandler());
            //initChat
            server.createContext("/initChat", new Handlers.initChatPostHandler());
            //logout
            server.createContext("/logout", new Handlers.logoutPostHandler());
            //sendChatAll
            server.createContext("/sendChatAll", new Handlers.sendChatAllPostHandler());
            //refreshListOnline
            server.createContext("/refreshListOnline", new Handlers.refreshListOnlinePostHandler());
            //refreshChatPage
            server.createContext("/refreshChatPage", new Handlers.refreshChatPagePostHandler());
            ////////////////////////////////////////////////////////
            

            server.setExecutor(null);
            server.start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void Stop() {
        server.stop(0);
        System.out.println("server stopped");
    }
}
