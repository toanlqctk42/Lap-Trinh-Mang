package WebChat;

import Utility.Client;
import Utility.ClientStatus;
import Utility.ClientTypes;
import Utility.Encrytion.MD5;
import Utility.WebChatLog;
import static WebChat.ClientThreadUtility.sendChatAllToChatApp;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Handlers {

    public static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";

    public static class RootHandler implements HttpHandler {

        @Override
        public void handle(HttpExchange he) throws IOException {
            String response = "<h1>Server start success if you see this message</h1>" + "<h1>Port: " + SimpleHttpsServer.port + "</h1>";
            he.sendResponseHeaders(200, response.length());
            OutputStream os = he.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }

    public static class EchoHeaderHandler implements HttpHandler {

        @Override
        public void handle(HttpExchange he) throws IOException {
            Headers headers = he.getRequestHeaders();
            Set<Map.Entry<String, List<String>>> entries = headers.entrySet();
            String response = "";
            for (Map.Entry<String, List<String>> entry : entries) {
                response += entry.toString() + "\n";
            }
            he.sendResponseHeaders(200, response.length());
            OutputStream os = he.getResponseBody();
            os.write(response.toString().getBytes());
            os.close();
        }
    }

    public static class EchoGetHandler implements HttpHandler {

        @Override
        public void handle(HttpExchange he) throws IOException {
            // parse request
            Map<String, Object> parameters = new HashMap<String, Object>();
            URI requestedUri = he.getRequestURI();
            String query = requestedUri.getRawQuery();
            parseQuery(query, parameters);
            // send response
            String response = "";
            for (String key : parameters.keySet()) {
                response += key + " = " + parameters.get(key) + "\n";
            }
            he.sendResponseHeaders(200, response.length());
            OutputStream os = he.getResponseBody();
            os.write(response.toString().getBytes());
            os.close();
        }

    }

    public static class EchoPostHandler implements HttpHandler {

        @Override
        public void handle(HttpExchange he) throws IOException {
            System.out.println("Served by /echoPost handler...");
            // parse request
            Map<String, Object> parameters = new HashMap<String, Object>();

            InputStreamReader isr = new InputStreamReader(he.getRequestBody(), "utf-8");
            BufferedReader br = new BufferedReader(isr);
            String query = br.readLine();
            parseQuery(query, parameters);
            // send response
            String response = "";
            for (String key : parameters.keySet()) {
                response += key + " = " + parameters.get(key) + "\n";
            }
            he.sendResponseHeaders(200, response.length());
            OutputStream os = he.getResponseBody();
            os.write(response.toString().getBytes());
            os.close();

        }
    }

    @SuppressWarnings("unchecked")
    public static void parseQuery(String query, Map<String, Object> parameters) throws UnsupportedEncodingException {

        if (query != null) {
            String pairs[] = query.split("[&]");

            for (String pair : pairs) {
                String param[] = pair.split("[=]");

                String key = null;
                String value = null;
                if (param.length > 0) {
                    key = URLDecoder.decode(param[0], System.getProperty("file.encoding"));
                }

                if (param.length > 1) {
                    value = URLDecoder.decode(param[1], System.getProperty("file.encoding"));
                }

                if (parameters.containsKey(key)) {
                    Object obj = parameters.get(key);
                    if (obj instanceof List<?>) {
                        List<String> values = (List<String>) obj;
                        values.add(value);
                    } else if (obj instanceof String) {
                        List<String> values = new ArrayList<String>();
                        values.add((String) obj);
                        values.add(value);
                        parameters.put(key, values);
                    }
                } else {
                    parameters.put(key, value);
                }
            }
        }
    }

    public static class loginPostHandler implements HttpHandler {

        @Override
        public void handle(HttpExchange he) throws IOException {
            // parse request
            Map<String, Object> parameters = new HashMap<String, Object>();
            ////////////////////////////
            //InetSocketAddress context = he.getRemoteAddress();
            //System.out.println(context);

            ////////////////////////////
            InputStreamReader isr = new InputStreamReader(he.getRequestBody(), "utf-8");
            BufferedReader br = new BufferedReader(isr);
            String query = br.readLine();
             System.out.println(query);
            parseQuery(query, parameters);
            final String username = (String) parameters.get("username");
            final String password = (String) parameters.get("pwd");
            System.out.println(username);
            System.out.println(password);
            ///
            //Check login
            ///
            try {
                Client cli = new Client();
                cli.userName = username;
                cli.password = MD5.getMD5(password);

                cli.iD = Client.checkLoginiD(cli, SimpleHttpsServer.main.clientList);

                String response = "";
                //System.out.println("/////////////////////////////////////////");
                //System.out.println(cli.iD);
                //////////////////////////////////////////////////////
                if (cli.iD > 0) {
                    //dos.writeUTF(AESEncryption.encryptTextUsingAES("0 " + cli.iD, aesKey));
                    cli.status = ClientStatus.online;
                    cli.clientTypes = ClientTypes.webchat;
                    //cli.socket = this.socket;
                    //aes key == web
                    SimpleHttpsServer.main.updateClient(cli, ClientStatus.online, "");
                    SimpleHttpsServer.main.addMessage("[Login]: " + cli.userName + " logged in form Web Services.!");
                    response = String.valueOf(cli.iD);
                    //String response = "100";

                } else if (cli.iD == -1) {
                    //dos.writeUTF(AESEncryption.encryptTextUsingAES("-1", aesKey));
                    //socket.close();
                    response = "-1";
                } else {
                    response = "0";
                    //dos.writeUTF(AESEncryption.encryptTextUsingAES("1", aesKey));
                    //socket.close();
                }
                he.getResponseHeaders().set(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
                he.sendResponseHeaders(200, response.length());
                OutputStream os = he.getResponseBody();
                os.write(response.toString().getBytes());
                os.close();

            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

        }
    }

    public static class initChatPostHandler implements HttpHandler {

        @Override
        public void handle(HttpExchange he) throws IOException {
            // parse request
            Map<String, Object> parameters = new HashMap<String, Object>();

            ////////////////////////////
            InputStreamReader isr = new InputStreamReader(he.getRequestBody(), "utf-8");
            BufferedReader br = new BufferedReader(isr);
            String query = br.readLine();
            System.out.println(query);
            System.out.println("/////////////////////////////////////////");
            parseQuery(query, parameters);
            final String sid = (String) parameters.get("sid");

            String response = Utility.Client.convertListToJson(SimpleHttpsServer.main.clientList);

            he.getResponseHeaders().set(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
            he.sendResponseHeaders(200, response.length());
            OutputStream os = he.getResponseBody();
            os.write(response.toString().getBytes());
            os.close();

            ///////
            ///System.out.println("test sid" + sid);
        }
    }

    public static class logoutPostHandler implements HttpHandler {

        @Override
        public void handle(HttpExchange he) throws IOException {
            // parse request
            Map<String, Object> parameters = new HashMap<String, Object>();
            ////////////////////////////
            InputStreamReader isr = new InputStreamReader(he.getRequestBody(), "utf-8");
            BufferedReader br = new BufferedReader(isr);
            String query = br.readLine();
            System.out.println(query);
            System.out.println("/////////////////////////////////////////");
            parseQuery(query, parameters);
            final String sid = (String) parameters.get("sid");
            Client cli = new Client();
            cli.iD = Integer.valueOf(sid);

            SimpleHttpsServer.main.updateClient(cli, ClientStatus.offline, "");
            SimpleHttpsServer.main.addMessage("[Logout]: " + cli.userName + " logged out form Web Services.!");

            String response = "logout";
            //System.out.println(cli.iD);
            he.getResponseHeaders().set(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
            he.sendResponseHeaders(200, response.length());
            OutputStream os = he.getResponseBody();
            os.write(response.toString().getBytes());
            os.close();

            ///////
            ///System.out.println("test sid" + sid);
        }
    }

    public static class sendChatAllPostHandler implements HttpHandler {

        @Override
        public void handle(HttpExchange he) throws IOException {
            // parse request
            Map<String, Object> parameters = new HashMap<String, Object>();
            ////////////////////////////
            InputStreamReader isr = new InputStreamReader(he.getRequestBody(), "utf-8");
            BufferedReader br = new BufferedReader(isr);
            String query = br.readLine();
            System.out.println(query);
            System.out.println("/////////////////////////////////////////");
            parseQuery(query, parameters);
            final String sid = (String) parameters.get("sid");
            final String message = (String) parameters.get("message");

            try {
                sendChatAllToChatApp(SimpleHttpsServer.main, Integer.valueOf(sid), message);
                WebChatLog log = new WebChatLog(SimpleHttpsServer.main.getUserNameByID(Integer.valueOf(sid)), message);
                SimpleHttpsServer.listLog.add(log);
            } catch (Exception ex) {
                //Logger.getLogger(Handlers.class.getName()).log(Level.SEVERE, null, ex);
            }

            String response = "Success";
            //System.out.println(cli.iD);
            he.getResponseHeaders().set(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
            he.sendResponseHeaders(200, response.length());
            OutputStream os = he.getResponseBody();
            os.write(response.toString().getBytes());
            os.close();
        }
    }

    public static class refreshListOnlinePostHandler implements HttpHandler {

        @Override
        public void handle(HttpExchange he) throws IOException {
            // parse request
            Map<String, Object> parameters = new HashMap<String, Object>();
            ////////////////////////////
            InputStreamReader isr = new InputStreamReader(he.getRequestBody(), "utf-8");
            BufferedReader br = new BufferedReader(isr);
            String query = br.readLine();
            System.out.println(query);
            System.out.println("/////////////////////////////////////////");
            System.out.println("Send Online List");
            parseQuery(query, parameters);
            //parseQuery(query, parameters);
            final String sid = (String) parameters.get("sid");

            String response = Utility.Client.convertListToJson(SimpleHttpsServer.main.clientList);

            he.getResponseHeaders().set(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
            he.sendResponseHeaders(200, response.length());
            OutputStream os = he.getResponseBody();
            os.write(response.toString().getBytes());
            os.close();
        }
    }

    public static class refreshChatPagePostHandler implements HttpHandler {

        @Override
        public void handle(HttpExchange he) throws IOException {
            // parse request
            Map<String, Object> parameters = new HashMap<String, Object>();
            ////////////////////////////
            InputStreamReader isr = new InputStreamReader(he.getRequestBody(), "utf-8");
            BufferedReader br = new BufferedReader(isr);
            String query = br.readLine();
            System.out.println(query);
            System.out.println("/////////////////////////////////////////");
            System.out.println("Send Chat");
            parseQuery(query, parameters);
            //parseQuery(query, parameters);
            final String sid = (String) parameters.get("sid");

            //String response =  Utility.Client.convertListToJson(SimpleHttpsServer.main.clientList);
            String response = Utility.WebChatLog.convertListToJson(SimpleHttpsServer.listLog);

            he.getResponseHeaders().set(ACCESS_CONTROL_ALLOW_ORIGIN, "*");
            he.sendResponseHeaders(200, response.length());
            OutputStream os = he.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }

}
