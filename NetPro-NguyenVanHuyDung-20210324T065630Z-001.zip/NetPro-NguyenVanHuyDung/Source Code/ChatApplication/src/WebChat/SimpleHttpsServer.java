package WebChat;

import Server.Main;
import Utility.WebChatLog;
import com.sun.net.httpserver.HttpsConfigurator;
import com.sun.net.httpserver.HttpsParameters;
import com.sun.net.httpserver.HttpsServer;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.List;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.TrustManagerFactory;

public class SimpleHttpsServer {

    public static int port;
    private HttpsServer server;
    private static String protocol = "TLS";
    
    public static Main main;
    
    public static List<WebChatLog> listLog;

    public void Start(int port, Main main) {
        try {
            this.port = port;
            this.main = main;
            // load certificate
            String keystoreFilename = "ServerKeyPair/mycert.keystore";
            char[] storepass = "mypassword".toCharArray();
            char[] keypass = "mypassword".toCharArray();
            String alias = "alias";
            FileInputStream fIn = new FileInputStream(keystoreFilename);
            KeyStore keystore = KeyStore.getInstance("JKS");
            keystore.load(fIn, storepass);
            // display certificate
//			Certificate cert = keystore.getCertificate(alias);
//			System.out.println(cert);

            // setup the key manager factory
            KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
            kmf.init(keystore, keypass);

            // setup the trust manager factory
            TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
            tmf.init(keystore);

            // create https server
            server = HttpsServer.create(new InetSocketAddress(port), 0);
            // create ssl context
            SSLContext sslContext = SSLContext.getInstance(protocol);
            // setup the HTTPS context and parameters
            sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);
            server.setHttpsConfigurator(new HttpsConfigurator(sslContext) {
                public void configure(HttpsParameters params) {
                    try {
                        // initialise the SSL context
                        SSLContext c = SSLContext.getDefault();
                        SSLEngine engine = c.createSSLEngine();
                        params.setNeedClientAuth(false);
                        params.setCipherSuites(engine.getEnabledCipherSuites());
                        params.setProtocols(engine.getEnabledProtocols());

                        // get the default parameters
                        SSLParameters defaultSSLParameters = c.getDefaultSSLParameters();
                        params.setSSLParameters(defaultSSLParameters);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        System.out.println("Failed to create HTTPS server");
                    }
                }
            });

            System.out.println("server started at " + port);
            
            listLog = new ArrayList<>();
            
            server.createContext("/", new Handlers.RootHandler());
            server.createContext("/echoHeader", new Handlers.EchoHeaderHandler());
            server.createContext("/echoGet", new Handlers.EchoGetHandler());
            server.createContext("/echoPost", new Handlers.EchoPostHandler());
            ////////////////////////////////////////////////////////
            //Login
            server.createContext("/login", new Handlers.loginPostHandler());
            //initChat
            server.createContext("/initChat", new Handlers.initChatPostHandler());
            //logout
            server.createContext("/logout", new Handlers.logoutPostHandler());
            //sendChatAll
            server.createContext("/sendChatAll", new Handlers.sendChatAllPostHandler());
            //refreshListOnline
            server.createContext("/refreshListOnline", new Handlers.refreshListOnlinePostHandler());
            //refreshChatPage
            server.createContext("/refreshChatPage", new Handlers.refreshChatPagePostHandler());
            ////////////////////////////////////////////////////////
            server.setExecutor(null);
            server.start();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (KeyStoreException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (CertificateException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (KeyManagementException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (UnrecoverableKeyException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void Stop() {
        server.stop(0);
        System.out.println("server stopped");
    }
}
