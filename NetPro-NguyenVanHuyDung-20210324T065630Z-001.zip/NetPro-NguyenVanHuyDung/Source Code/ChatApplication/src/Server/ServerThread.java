/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Server;

import Utility.Encrytion.AsymmetricCryptography;
import WebChat.SimpleHttpsServer;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

/**
 *
 * @author VTB
 */
public class ServerThread implements Runnable {

    ServerSocket server;
    //SimpleHttpServer httpServer;
    SimpleHttpsServer httpsServer;
    Main main;
    boolean alive = true;
    DataInputStream dis;
    DataOutputStream dos;

    public ServerThread(int port, Main main) {

        try {
            this.main = main;
            server = new ServerSocket(port);
            main.addMessage("[Server]: Server is working.!");
            main.addMessage("[Server]: Server is working at port " + port);
            
            ////////////////////////////////////////////////
            //WebChat Server
            ////////////////////////////////////////////////
            int webport = 8888;
            httpsServer = new SimpleHttpsServer();
            httpsServer.Start(webport, main);
            main.addMessage("[WEB Server]: WEB Server is working.!");
            main.addMessage("[WEB Server]: WEB Server is working at port " + webport);
            ////////////////////////////////////////////////
        } catch (IOException ex) {
            main.addMessage("[IOException]: " + ex.getMessage());
            System.out.println(ex.getMessage());
        }
    }

    @Override
    public void run() {

        try {
            while (alive) {
                synchronized (this) {
                    Socket socket = server.accept();

                    dos = new DataOutputStream(socket.getOutputStream());
                    dis = new DataInputStream(socket.getInputStream());

                    //Send public key for Client
                    dos.writeInt(main.publicKey.getEncoded().length);
                    dos.write(main.publicKey.getEncoded());
                    
                    //Receiver aesKey form Client
                    String encrypt = dis.readUTF();
                    AsymmetricCryptography ac = new AsymmetricCryptography();
                    String aesKey = ac.decryptText(encrypt, main.privateKey);
                    //
                    /**
                     * Client socket thread *
                     */
                    new Thread(new ClientThread(socket, main, aesKey, httpsServer)).start();
                }
            }
        } catch (IOException | NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException ex) {
            main.addMessage("[ServerThread-IOException]: " + ex.getMessage());
            System.out.println(ex.getMessage());
        }
    }

    public void stop() {
        try {
            server.close();
            alive = false;
            System.exit(0);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
