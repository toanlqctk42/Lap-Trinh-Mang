/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Server;

import Utility.Encrytion.AESEncryption;
import Utility.MessageType;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;



/**
 *
 * @author VTBmag
 */
public class ListUserThread implements Runnable {

    Main main;

    public ListUserThread(Main main) {
        this.main = main;
    }

    @Override
    public void run() {
        while (!Thread.interrupted()) {
            //synchronized (this) {
            try {
                String msg = Utility.Client.convertListToJson(main.clientList);
                for (int i = 0; i < main.clientList.size(); i++) {
                    Socket tsoc = (Socket) main.clientList.get(i).socket;
                    if (tsoc != null && !tsoc.isClosed() ) {
                        DataOutputStream dos = new DataOutputStream(tsoc.getOutputStream());
                        /**
                         * Format [MessageType.listonline.toString()] [List Client to json]
                         */
                        
                        dos.writeUTF(AESEncryption.encryptTextUsingAES(MessageType.listonline.toString() + " " + msg, main.clientList.get(i).aesKey));
                    }
                }
                //periodic 2s
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                main.addMessage("[InterruptedException]: " + e.getMessage());
            } catch (IOException e) {
                main.addMessage("[IOException]: " + e.getMessage());
            } catch (Exception e) {
                 main.addMessage("[Exception]: " + e.getMessage());
            }
        }
    }
}
