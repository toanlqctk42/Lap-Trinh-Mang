/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Server;

import Utility.Client;
import Utility.ClientStatus;
import Utility.ClientTypes;
import Utility.Encrytion.AESEncryption;
import Utility.Message;
import Utility.MessageType;
import Utility.TransferFile;
import Utility.WebChatLog;
import WebChat.SimpleHttpsServer;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.security.NoSuchAlgorithmException;
import java.util.StringTokenizer;
import javax.crypto.NoSuchPaddingException;

/**
 *
 * @author VTB
 */
public class ClientThread implements Runnable {

    private Socket socket;
    private Main main;
    //private SimpleHttpServer httpServer;
    private SimpleHttpsServer httpsServer;
    private DataInputStream dis;
    private StringTokenizer st;
    private Client cli;
    private String aesKey;

    private final int BUFFER_SIZE = 2048;

    public ClientThread(Socket socket, Main main) {
        this.main = main;
        this.socket = socket;
        this.cli = new Client();
        try {
            dis = new DataInputStream(socket.getInputStream());
        } catch (IOException e) {
            main.addMessage("[SocketThreadIOException]: " + e.getMessage());
        }
    }

    public ClientThread(Socket socket, Main main, String aesKey, SimpleHttpsServer httpsServer) {
        this.main = main;
        this.socket = socket;
        this.aesKey = aesKey;
        this.httpsServer = httpsServer;

        this.cli = new Client();
        try {
            dis = new DataInputStream(socket.getInputStream());
        } catch (IOException e) {
            main.addMessage("[SocketThreadIOException]: " + e.getMessage());
        }
    }

    /*   Hàm này sẽ lấy client socket trong danh sách client socket sau đó sẽ thiết lập kết nối    */
    private void createSocketSendFile(TransferFile sendfile) {
        try {
            main.addMessage("[createSocketSendFile]: Creating connection to share file.");

            //Lấy socket từ main
            Client client = main.getClient(sendfile.idReceiver);
            Socket s = client.socket;

            if (s.isClosed()) {// Client không tồn tại, gửi lại cho sender rằng receiver không tìm thấy.
                main.addMessage("[createSocketSendFile]: Client doesn't exit '" + sendfile.idReceiver + "'");
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                String format = MessageType.sendfileerror + " " + "Client '" + sendfile.idReceiver + "' doesn't online.!";
                dos.writeUTF(AESEncryption.encryptTextUsingAES(format, aesKey));
            } else { // Client đã tồn tại
                main.addMessage("[createSocketSendFile]: Socket OK");
                DataOutputStream dosS = new DataOutputStream(s.getOutputStream());
                main.addMessage("[createSocketSendFile]: DataOutputStream OK");
                // Format:  [MessageType.sendfilexd] [sendfile.convertToJson()]
                String content = sendfile.convertToJson();
                String format = MessageType.sendfilexd + " " + content;
                dosS.writeUTF(AESEncryption.encryptTextUsingAES(format, client.aesKey));
                main.addMessage("[createSocketSendFile]: " + format);
            }
        } catch (IOException e) {
            main.addMessage("[createSocketSendFile - IOException]: " + e.getLocalizedMessage());
        } catch (Exception e) {
            main.addMessage("[createSocketSendFile - Exception]: " + e.getLocalizedMessage());
        }
    }

    private void sendOnlineList() throws JsonProcessingException, IOException, Exception {
        String msg = Client.convertListToJson(main.clientList);
        for (int i = 0; i < main.clientList.size(); i++) {
            Socket tsoc = (Socket) main.clientList.get(i).socket;
            if (tsoc != null && !tsoc.isClosed()) {
                DataOutputStream dos = new DataOutputStream(tsoc.getOutputStream());
                /**
                 * Format [MessageType.listonline.toString()] [List Client to json]
                 */
                dos.writeUTF(AESEncryption.encryptTextUsingAES(MessageType.listonline.toString() + " " + msg, main.clientList.get(i).aesKey));
            }
        }
    }

    @Override
    public void run() {
        try {
            while (true) {
                //////////////////////////////////////////////////////
                String encrypt = dis.readUTF();
                String data = AESEncryption.decryptTextUsingAES(encrypt, aesKey);
                //////////////////////////////////////////////////////
                st = new StringTokenizer(data);
                String type = st.nextToken();
                //////////////////////////////////////////////////////
                MessageType messageType = MessageType.valueOf(type);
                //////////////////////////////////////////////////////
                /**
                 * check messageType *
                 */
                switch (messageType) {
                    case login:
                        synchronized (this) {
                            //////////////////////////////////////////////////////
                            DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                            String json = st.nextToken();
                            cli = Client.convertToOject(json);
                            cli.iD = Client.checkLoginiD(cli, main.clientList);
                            //////////////////////////////////////////////////////
                            if (cli.iD > 0) {
                                dos.writeUTF(AESEncryption.encryptTextUsingAES("0 " + cli.iD, aesKey));
                                cli.status = ClientStatus.online;
                                cli.socket = this.socket;
                                cli.clientTypes = ClientTypes.application;
                                main.updateClient(cli, ClientStatus.online, aesKey);
                                main.addMessage("[Login]: " + cli.userName + " haved just logged in.!");
                                sendOnlineList();
                            } else if (cli.iD == -1) {
                                //Đã đăng nhập
                                dos.writeUTF(AESEncryption.encryptTextUsingAES("-1", aesKey));
                                socket.close();
                            } else {
                                //Sai thông tin đăng nhập
                                dos.writeUTF(AESEncryption.encryptTextUsingAES("1", aesKey));
                                socket.close();
                            }
                            break;
                        }
                    case chat:
                        synchronized (this) {
                            //////////////////////////////////////////////////////
                            String content = "";
                            while (st.hasMoreTokens()) {
                                content = content + " " + st.nextToken();
                            }
                            Message message = Message.convertToOject(content);
                            //////////////////////////////////////////////////////
                            Client client = main.getClient(message.reciever);
                            Socket soc = client.socket;
                            // chỉ gửi khi có kết nối socket
                            if (soc != null && !soc.isClosed()) {
                                try {
                                    DataOutputStream dos2 = new DataOutputStream(soc.getOutputStream());
                                    //1 chat one to one
                                    dos2.writeUTF(AESEncryption.encryptTextUsingAES(MessageType.message.toString() + " " + "1" + " " + content, client.aesKey));
                                } catch (IOException e) {
                                    main.addMessage("[CHAT-IOException]: Cannot send message to " + message.reciever);
                                }
                            } else {
                                try {
                                    //gửi thông báo cho client
                                    DataOutputStream dos2 = new DataOutputStream(socket.getOutputStream());
                                    //1 chat one to one
                                    dos2.writeUTF(AESEncryption.encryptTextUsingAES(MessageType.message.toString() + " " + "2" + " " + content, aesKey));
                                } catch (IOException e) {
                                    main.addMessage("[IOException]: Cannot send message to " + message.sender);
                                }
                            }
                            break;
                        }
                    case chatall:
                        synchronized (this) {
                            String content = "";
                            while (st.hasMoreTokens()) {
                                content = content + " " + st.nextToken();
                            }
                            Message message = Message.convertToOject(content);
                            
                            ////////////////
                            //Log Chat for Web Chat
                            ////////////////
                            WebChatLog log = new WebChatLog(main.getUserNameByID(message.sender), message.content);
                            httpsServer.listLog.add(log);
                            ////////////////
                                    
                            for (Client client : main.clientList) {
                                if (client.clientTypes != null) {
                                    if (client.clientTypes.equals(ClientTypes.application)) {
                                        if (client.iD != message.sender) {
                                            try {
                                                Socket tsoc2 = client.socket;
                                                if (tsoc2 != null) {
                                                    DataOutputStream dos2 = new DataOutputStream(tsoc2.getOutputStream());
                                                    // "0" message for all
                                                    dos2.writeUTF(AESEncryption.encryptTextUsingAES(MessageType.message.toString() + " " + "0" + " " + content, client.aesKey));
                                                }
                                            } catch (IOException e) {
                                                main.addMessage("[CHATALL-IOException]: " + e.getMessage());
                                            }
                                        }
                                    } 
                                }
                            }
                            main.addMessage("[CHATALL]: " + message);
                            break;
                        }
                    case createsendfilesocket:
                        synchronized (this) {
                            main.addMessage("[Createsendfilesocket] : Client has established connection to share file...");
                            String idsender = st.nextToken();
                            String idreceiver = st.nextToken();

                            TransferFile transferFile = new TransferFile(Integer.valueOf(idsender), Integer.valueOf(idreceiver));
                            transferFile.socket = socket;
                            main.listtransfer.add(transferFile);

                            main.addMessage("[Createsendfilesocket] : Username: " + idsender);
                            main.addMessage("[Createsendfilesocket] : Socket for File Sharing is opening");
                            break;
                        }

                    case sendfile:
                        synchronized (this) {
                            main.addMessage("SENDFILE : Sending File...");

                            String content = "";
                            while (st.hasMoreTokens()) {
                                content = content + " " + st.nextToken();
                            }
                            TransferFile transfer = TransferFile.convertToOject(content);

                            main.addMessage("SENDFILE : From: " + transfer.idSender);
                            main.addMessage("SENDFILE : To: " + transfer.idReceiver);
                            /**
                             *  client Socket *
                             */
                            main.addMessage("SENDFILE : ready for connection..");

                            Socket cSock = main.getSocketTransferFile(transfer.idReceiver, transfer.idSender);
                            Client client = main.getClient(transfer.idReceiver);

                            if (cSock != null && !cSock.isClosed()) {
                                /* Exists   */

                                try {
                                    main.addMessage("SENDFILE : Connected..!");
                                    /**
                                     * Write filename.. *
                                     */
                                    main.addMessage("CMD_SENDFILE : File Transfering...");
                                    DataOutputStream cDos = new DataOutputStream(cSock.getOutputStream());
                                    String format = MessageType.sendfile.toString() + " " + content;
                                    cDos.writeUTF(AESEncryption.encryptTextUsingAES(format, client.aesKey));

                                    /**
                                     * read file *
                                     */
                                    InputStream input = socket.getInputStream();
                                    OutputStream sendFile = cSock.getOutputStream();
                                    byte[] buffer = new byte[BUFFER_SIZE];
                                    int cnt;
                                    while ((cnt = input.read(buffer)) > 0) {
                                        sendFile.write(buffer, 0, cnt);
                                    }
                                    sendFile.flush();
                                    sendFile.close();
                                    /**
                                     * remove socket transfer file
                                     */
                                    main.removeSocketTransferfile(transfer.idSender, transfer.idReceiver);
                                    main.removeSocketTransferfile(transfer.idReceiver, transfer.idSender);
                                    main.addMessage("CMD_SENDFILE : Successful transfer file to client...");
                                } catch (IOException e) {
                                    main.addMessage("[CMD_SENDFILE]: " + e.getMessage());
                                }
                            } else {
                                /*   Không tồn tại, return error  */
 /*   FORMAT: CMD_SENDFILEERROR  */
                                main.removeSocketTransferfile(transfer.idSender, transfer.idSender);
                                main.addMessage("CMD_SENDFILE : Client '" + String.valueOf(transfer.idReceiver) + "' doesn't exit.!");
                                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                                String format = MessageType.sendfileerror + " " + "Client '" + String.valueOf(transfer.idReceiver) + "' doesn't online.";
                                dos.writeUTF(AESEncryption.encryptTextUsingAES(format, aesKey));
                            }
                            break;
                        }

                    case sendfileresponse:
                        synchronized (this) {
                            /*
                         Format: CMD_SENDFILERESPONSE [username] [Message]
                             */
                            String receiver = st.nextToken(); // phương thức nhận receiver username
                            String sender = st.nextToken(); // phương thức nhận receiver username
                            String rMsg = ""; // phương thức nhận error message
                            main.addMessage("[CMD_SENDFILERESPONSE]: username: " + receiver);
                            while (st.hasMoreTokens()) {
                                rMsg = rMsg + " " + st.nextToken();
                            }
                            try {
                                Socket rSock = (Socket) main.getSocketTransferFile(Integer.valueOf(receiver), Integer.valueOf(sender));
                                Client client = main.getClient(Integer.valueOf(receiver));
                                DataOutputStream rDos = new DataOutputStream(rSock.getOutputStream());
                                //
                                String format = MessageType.sendfileresponse.toString() + " " + receiver + " " + rMsg;
                                //
                                rDos.writeUTF(AESEncryption.encryptTextUsingAES(format, client.aesKey));
                            } catch (IOException e) {
                                main.addMessage("[CMD_SENDFILERESPONSE]: " + e.getMessage());
                            }
                            break;

                        }

                    case sendfilexd:
                        synchronized (this) {
                            try {
                                String content = "";
                                while (st.hasMoreTokens()) {
                                    content = content + " " + st.nextToken();
                                }

                                TransferFile sendfile = TransferFile.convertToOject(content);

                                main.addMessage("[CMD_SEND_FILE_XD]: Host: " + sendfile.idSender);

                                this.createSocketSendFile(sendfile);
                            } catch (Exception e) {
                                main.addMessage("[CMD_SEND_FILE_XD]: " + e.getLocalizedMessage());
                            }
                            break;
                        }

                    case sendfileerror:
                        synchronized (this) {
                            String eReceiver = st.nextToken();
                            String eSender = st.nextToken();
                            String eMsg = "";
                            while (st.hasMoreTokens()) {
                                eMsg = eMsg + " " + st.nextToken();
                            }
                            try {
                                /*  Gửi Error đến File Sharing host  */
                                //Socket eSock = main.getClientFileSharingSocket(eReceiver); // phương thức nhận file sharing host socket cho kết nối
                                Socket eSock = main.getSocketTransferFile(Integer.valueOf(eReceiver), Integer.valueOf(eSender)); // phương thức nhận file sharing host socket cho kết nối
                                Client client = main.getClient(Integer.valueOf(eReceiver));
                                DataOutputStream eDos = new DataOutputStream(eSock.getOutputStream());
                                //  Format:  CMD_RECEIVE_FILE_ERROR [Message]

                                String format = MessageType.receivefileerror + " " + eMsg;
                                eDos.writeUTF(AESEncryption.encryptTextUsingAES(format, client.aesKey));
                            } catch (IOException e) {
                                main.addMessage("[CMD_RECEIVE_FILE_ERROR]: " + e.getMessage());
                            }
                            break;
                        }
                    case sendfileaccept:
                        synchronized (this) {
                            String aReceiver = st.nextToken();
                            String aSender = st.nextToken();
                            String aMsg = "";
                            while (st.hasMoreTokens()) {
                                aMsg = aMsg + " " + st.nextToken();
                            }
                            try {
                                /*  Send Error to the File Sharing host  */
                                //Socket aSock = main.getClientFileSharingSocket(aReceiver); // get the file sharing host socket for connection
                                Socket aSock = main.getSocketTransferFile(Integer.valueOf(aReceiver), Integer.valueOf(aSender)); // get the file sharing host socket for connection
                                Client client = main.getClient(Integer.valueOf(aReceiver));
                                DataOutputStream aDos = new DataOutputStream(aSock.getOutputStream());
                                //  Format:  CMD_RECEIVE_FILE_ACCEPT [Message]
                                //aDos.writeUTF("CMD_RECEIVE_FILE_ACCEPT " + aMsg);
                                String format = MessageType.receivefileaccept + " " + aMsg;
                                aDos.writeUTF(AESEncryption.encryptTextUsingAES(format, client.aesKey));
                            } catch (IOException e) {
                                main.addMessage("[CMD_RECEIVE_FILE_ERROR]: " + e.getMessage());
                            }
                            break;
                        }
                    default:
                        throw new AssertionError();
                }
                ///////////////////////////////////////////////////

            }
        } catch (IOException e) {
            try {
                /*   đây là hàm chatting client, remove nếu như nó tồn tại..   */
                socket.close();
                main.updateStatusClient(cli.iD, ClientStatus.offline);
                main.addMessage("[SocketThread]: Socket is closed..!");
                sendOnlineList();
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
        } catch (NoSuchAlgorithmException ex) {
            System.out.println(ex.getMessage());
        } catch (NoSuchPaddingException ex) {
            System.out.println(ex.getMessage());
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

    }
}
