/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

import Utility.Client;
import Utility.ClientStatus;

import Utility.Encrytion.AsymmetricCryptography;
import Utility.Encrytion.GenerateKeys;
import Utility.TransferFile;
import java.awt.Toolkit;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.NoSuchPaddingException;

/**
 *
 * @author VTB
 */
public final class Main extends javax.swing.JFrame {

    SimpleDateFormat dateformat = new SimpleDateFormat("hh:mm:ss a");
    Thread t;
    ServerThread serverThread;
    //SimpleHttpServer httpServer;
    
    /**
     * Chat List 
     */
    public List<Client> clientList = new ArrayList<>();

    /**
     * File Sharing List 
     */
    public List<TransferFile> listtransfer = new ArrayList<>();
    
    /**
     * Server *
     */
    ServerSocket server;

    /**
     * RSA PrivateKey 
     */
    public PrivateKey privateKey = null;
    
    /**
     * RSA PublicKey
     */
    public PublicKey publicKey = null;

    
     /**
     * Creates new form Main
     *
     * @throws java.io.IOException
     */
    public Main() throws IOException {
        initComponents();
        seticon();
    }

    
    void seticon() {
        this.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("chat-icon.png")));
    }
    
    /**
     *
     * @throws IOException
     */
    public void getAllClient() throws IOException {
        clientList = Client.readFormFileToObject();
    }
    
    /**
     *
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws Exception
     */
    public void getKeyRSA() throws NoSuchAlgorithmException, NoSuchPaddingException, Exception{
        GenerateKeys.GenerateKeys();
        AsymmetricCryptography ac = new AsymmetricCryptography();
        privateKey = ac.getPrivate("ServerKeyPair/privateKey");
        publicKey = ac.getPublic("ServerKeyPair/publicKey");
    }

    /**
     *
     * @param id
     * @param status
     */
    public void updateStatusClient(int id, ClientStatus status) {
        for (Client client : clientList) {
            if (client.iD == id) {
                client.status = status;
                break;
            }
        }
    }

    /**
     *
     * @param cli
     * @param status
     */
    public void updateStatusClient(Client cli, ClientStatus status) {
        synchronized (this) {
            for (Client client : clientList) {
                if (client.iD == cli.iD) {
                    client.status = status;
                    client.socket = cli.socket;
                    break;
                }
            }
        }
    }
    
    /**
     *
     * @param cli
     * @param status
     * @param aesKey
     */
    public void updateClient(Client cli, ClientStatus status, String aesKey) {
        synchronized (this) {
            for (Client client : clientList) {
                if (client.iD == cli.iD) {
                    client.status = status;
                    client.socket = cli.socket;
                    client.aesKey = aesKey;
                    client.clientTypes = cli.clientTypes;
                    
                    break;
                }
            }
        }
    }

    /**
     *
     * @param msg
     */
    public void addMessage(String msg) {
        Date date = new Date();
        txtArea.append(dateformat.format(date) + ": " + msg + "\n");
        txtArea.setCaretPosition(txtArea.getText().length() - 1);
    }
    
    /**
     *
     * @param iD
     * @return
     */
    public String getUserNameByID(int iD) {
        for (Client cli : clientList) {
            if (cli.iD == iD) {
                return cli.userName;
            }
        }
        return null;
    }
    
    /**
     *
     * @param iD
     * @return
     */
    public Socket getSocket(int iD) {
        try {
            for (Client client : clientList) {
                if (client.iD == iD) {
                    return client.socket;
                }
            }
        } catch (Exception e) {
            addMessage("[getSocket]: " + e.getMessage());
            System.out.println(e.getMessage());
        }
        return null;
    }
    
    /**
     *
     * @param iD
     * @return
     */
    public Client getClient(int iD){
        try {
            for (Client client : clientList) {
                if (client.iD == iD) {
                    return client;
                }
            }
        } catch (Exception e) {
            addMessage("[getSocket]: " + e.getMessage());
            System.out.println(e.getMessage());
        }
        return null;
    }

    /**
     *
     * @param idSender
     * @param idReciever
     * @return
     */
    public Socket getSocketTransferFile(int idSender, int idReciever) {
        try {
            for (TransferFile transferFile : listtransfer) {
                if (transferFile.idSender == idSender 
                        && transferFile.idReceiver == idReciever){ 
                    return transferFile.socket;
                }
            }
        } catch (Exception e) {
            addMessage("[getSocket]: " + e.getMessage());
            System.out.println(e.getMessage());
        }
        return null;
    }
    
    /**
     * 
     * @param idSender
     * @param idReciever
     */
    public void removeSocketTransferfile(int idSender, int idReciever) {
        synchronized (this) {
            try {
                for (TransferFile transferFile : listtransfer) {
                    if (transferFile.idSender == idSender
                            && transferFile.idReceiver == idReciever) {
                        listtransfer.remove(transferFile);
                        break;
                    }
                }
            } catch (Exception ex) {
                addMessage("[getSocket]: " + ex.getMessage());
                System.out.println(ex.getMessage());
            }
        }

    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtArea = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        btnStart = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        txtPort = new javax.swing.JTextField();
        Clear = new javax.swing.JButton();
        btnStop = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImage(getIconImage());
        setResizable(false);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/chat.png"))); // NOI18N

        txtArea.setEditable(false);
        txtArea.setColumns(20);
        txtArea.setRows(5);
        jScrollPane1.setViewportView(txtArea);
        txtArea.getAccessibleContext().setAccessibleName("txtArea");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Chat Server");

        btnStart.setText("Start");
        btnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStartActionPerformed(evt);
            }
        });

        jLabel3.setText("PORT:");

        txtPort.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtPort.setText("9999");

        Clear.setText("Clear");
        Clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearActionPerformed(evt);
            }
        });

        btnStop.setText("Stop");
        btnStop.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnStopActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnStop, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtPort, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(btnStart, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Clear, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtPort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnStart)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Clear)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnStop))
        );

        btnStart.getAccessibleContext().setAccessibleName("btnStart");
        btnStop.getAccessibleContext().setAccessibleName("btnStop");

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStartActionPerformed
        try {
            // TODO add your handling code here:
            synchronized (this) {
                int port = Integer.parseInt(txtPort.getText());

                serverThread = new ServerThread(port, this);

                t = new Thread(serverThread);

                t.start();

                new Thread(new ListUserThread(this)).start();

                btnStart.setEnabled(false);

                btnStop.setEnabled(true);

                getAllClient();
                
                getKeyRSA();
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        } catch (NoSuchPaddingException ex) {
           System.out.println(ex.getMessage());
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

    }//GEN-LAST:event_btnStartActionPerformed

    private void ClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearActionPerformed
        // TODO add your handling code here:
        txtArea.setText("");
    }//GEN-LAST:event_ClearActionPerformed

    private void btnStopActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnStopActionPerformed
        // TODO add your handling code here:
        int confirm = JOptionPane.showConfirmDialog(null, "Ban có muốn tắt server.?");
        if (confirm == 0) {
            serverThread.stop();
        }
    }//GEN-LAST:event_btnStopActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            System.out.println(ex.getMessage());
        }
        //</editor-fold>
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    new Main().setVisible(true);
                } catch (IOException ex) {
                    System.out.println(ex.getMessage());
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Clear;
    private javax.swing.JButton btnStart;
    private javax.swing.JButton btnStop;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txtArea;
    private javax.swing.JTextField txtPort;
    // End of variables declaration//GEN-END:variables
}
