package Client;

import Utility.Encrytion.AESEncryption;
import Utility.MessageType;
import Utility.TransferFile;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.util.StringTokenizer;
import javax.swing.JOptionPane;
import javax.swing.ProgressMonitorInputStream;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author VTB
 */
public class ReceivingFileThread implements Runnable {

    protected Socket socket;
    protected DataInputStream dis;
    protected DataOutputStream dos;
    protected Chat main;
    protected StringTokenizer st;
    private final int BUFFER_SIZE = 2048;

    public ReceivingFileThread(Socket soc, Chat main) {
        this.socket = soc;
        this.main = main;
        try {
            dos = new DataOutputStream(socket.getOutputStream());
            dis = new DataInputStream(socket.getInputStream());
        } catch (IOException e) {
            System.out.println("[ReceivingFileThread]: " + e.getMessage());
        }
    }

    @Override
    public void run() {
        try {
            while (!Thread.currentThread().isInterrupted()) {
                String encrypt = dis.readUTF();
                //System.out.println(encrypt);
                String data = AESEncryption.decryptTextUsingAES(encrypt, main.main.aesKey);

                st = new StringTokenizer(data);
                String type = st.nextToken();

                MessageType messageType = MessageType.valueOf(type);
                TransferFile transfer = null;

                switch (messageType) {
                    //   hàm này sẽ xử lý việc nhận một file trong một tiến trình nền xử lý từ một user khác
                    case sendfile:
                        try {
                            String content = "";
                            while (st.hasMoreTokens()) {
                                content = content + " " + st.nextToken();
                            }
                            transfer = TransferFile.convertToOject(content);

                            main.setMyTitle("Downloading....");
                            main.disableGUI(true);
                            //System.out.println("Downloading....");
                           // System.out.println("From: " + transfer.idReceiver);
                            String path = main.getMyDownloadFolder() + transfer.filename;
                            /*  Creat Stream   */
                            FileOutputStream fos = new FileOutputStream(path);
                            InputStream input = socket.getInputStream();
                            /*  Monitor Progress   */
                            ProgressMonitorInputStream pmis = new ProgressMonitorInputStream(main, "Downloading file please wait...", input);
                            /*  Buffer   */
                            BufferedInputStream bis = new BufferedInputStream(pmis);
                            /**
                             * Create a temporary file *
                             */
                            byte[] buffer = new byte[BUFFER_SIZE];
                            int count, percent = 0;
                            while ((count = bis.read(buffer)) != -1) {
                                percent = percent + count;
                                //int p = (percent / transfer.fileSize);
                                int p = (percent / transfer.fileSize) / (2048 / 100);
                                main.updateProgress(p);
                                main.setMyTitle("Downloading File  " + p + "%");
                                fos.write(buffer, 0, count);
                            }
                            fos.flush();
                            fos.close();
                            main.setMyTitle("You are logged in as: " + main.getMyUsername());
                            JOptionPane.showMessageDialog(main, "File saved as \n'" + path + "'");
                            //System.out.println("File saved: " + path);
                            socket.close();
                            main.disableGUI(false);
                        } catch (IOException e) {
                            try {
                                /*
                        Gửi lại thông báo lỗi đến sender
                        Định dạng: CMD_SENDFILERESPONSE [username] [Message]
                                 */
                                DataOutputStream eDos = new DataOutputStream(socket.getOutputStream());
                                String format = MessageType.sendfileresponse.toString() + " " + transfer.idSender + " " + transfer.idReceiver + " Kết nối bị mất, vui lòng thử lại lần nữa.!";
                                eDos.writeUTF(AESEncryption.encryptTextUsingAES(format, main.main.aesKey));

                                //System.out.println(e.getMessage());
                                main.setMyTitle("You are logged in as: " + main.getMyUsername());
                                JOptionPane.showMessageDialog(main, e.getMessage(), "Exception", JOptionPane.ERROR_MESSAGE);
                                socket.close();
                            } catch (Exception ex) {
                                System.out.println("[ReceivingFileThread]: " + ex.getMessage());
                            }
                        }
                        break;
                }
            }
        } catch (IOException e) {
            System.out.println("[ReceivingFileThread]: " + e.getMessage());
        } catch (Exception ex) {
            System.out.println("[ReceivingFileThread]: " + ex.getMessage());
        }
    }
}
