/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client;

import Utility.Client;
import Utility.Encrytion.AESEncryption;
import Utility.Encrytion.AsymmetricCryptography;
import Utility.Message;
import Utility.MessageStyle;
import Utility.MessageType;
import Utility.TransferFile;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.awt.Color;
import java.awt.Toolkit;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.Socket;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.StringTokenizer;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 *
 * @author VTB
 */
public final class Chat extends javax.swing.JFrame {

    public Client client;
    Socket socket;
    ClientMain main;

    private DataInputStream dis;
    private DataOutputStream dos;
    private StringTokenizer st;

    private String pathFile;

    private String mydownloadfolder = "";
    private PublicKey publicKey = null;
    ////

    /**
     * Các phương thức dùng để truyền file
     *
     * @return
     */
    /*
        Phương thức này được gọi đến khi người dùng click vào menu “Gửi File”, 
    sau đó kết nối đến Server và bắt đầu sẵn sàng để gửi file
     */
    public boolean createSocketTransferFile() {
        try {
            socket = new Socket(main.getMyHost(), main.getMyPort());
            dos = new DataOutputStream(socket.getOutputStream());
            dis = new DataInputStream(socket.getInputStream());

            ////// Send public key
            int lenght = dis.readInt();
            byte[] publickey = new byte[lenght];
            dis.read(publickey);

            this.publicKey = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(publickey));

            //Send aeskey
            AsymmetricCryptography ac = new AsymmetricCryptography();
            
            dos.writeUTF(ac.encryptText(main.aesKey, this.publicKey));

            String format = MessageType.createsendfilesocket.toString() + " " + main.client.iD + " " + client.iD;

            dos.writeUTF(AESEncryption.encryptTextUsingAES(format, main.aesKey));

            /*  Khởi động SendFile Thread    */
            new Thread(new Chat.TransferFileThread(this)).start();
            return true;
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return false;
    }

    /*   Phương thức SendFileThread này sẽ gửi yêu cầu chuyển dữ liệu đến Server   */
    class TransferFileThread implements Runnable {

        private final Chat chatmain;

        public TransferFileThread(Chat form) {
            this.chatmain = form;
        }

        private void closeMe() {
            try {
                socket.close();
                chatmain.disableGUI(false);
            } catch (IOException e) {
                System.out.println("[closeMe]: " + e.getMessage());
            }
        }

        @Override
        public void run() {
            try {
                while (!Thread.currentThread().isInterrupted()) {
                    String encrypt = dis.readUTF();// Đọc nội dung của dữ liệu được nhận từ Server
                    
                    String data = AESEncryption.decryptTextUsingAES(encrypt, main.aesKey);
                    st = new StringTokenizer(data);
                    String cmd = st.nextToken();  //  Lấy chữ đầu tiên từ dữ liệu

                    MessageType messageType = MessageType.valueOf(cmd);

                    switch (messageType) {
                        case receivefileerror:  // Định dạng: CMD_RECEIVE_FILE_ERROR [Message]
                            synchronized (this) {
                                String msg = "";
                                while (st.hasMoreTokens()) {
                                    msg = msg + " " + st.nextToken();
                                }
                                JOptionPane.showMessageDialog(Chat.this, msg, "Error", JOptionPane.ERROR_MESSAGE);
                                this.closeMe();
                                break;
                            }

                        case receivefileaccept:  // Định dạng: CMD_RECEIVE_FILE_ACCEPT [Message]
                            /*  Bắt đầu khởi động thread File đính kèm   */
                            synchronized (this) {
                                new Thread(new SendingFileThread(socket, pathFile, client.iD, main.client.iD, Chat.this)).start();
                                break;
                            }

                        case sendfileerror:
                            String emsg = "";
                            while (st.hasMoreTokens()) {
                                emsg = emsg + " " + st.nextToken();
                            }
                            System.out.println(emsg);
                            JOptionPane.showMessageDialog(Chat.this, emsg, "Error", JOptionPane.ERROR_MESSAGE);
                            chatmain.disableGUI(false);
                            break;

                        case sendfileresponse:
                            /*
                            Format: CMD_SENDFILERESPONSE [username] [Message]
                             */
                            String rReceiver = st.nextToken();
                            String rMsg = "";
                            while (st.hasMoreTokens()) {
                                rMsg = rMsg + " " + st.nextToken();
                            }
                            JOptionPane.showMessageDialog(Chat.this, rMsg, "Error", JOptionPane.ERROR_MESSAGE);
                            disableGUI(false);
                            break;
                    }
                }
            } catch (IOException e) {
                System.out.println(e.getMessage());
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }

    }

    /**
     * Creates new form Chat
     */
    public Chat() {
        initComponents();
        seticon();
        disableGUI(false);
        
    }

    void seticon() {
        this.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("userchat.png")));

    }

    public Chat(Client client, Socket socket, ClientMain main) {
        initComponents();
        seticon();
        this.client = client;
        this.socket = socket;
        this.main = main;
        this.lblUsername.setText("" + client.userName);
        this.setTitle("You are logged in as: " + main.client.userName);
        this.disableGUI(false);
        lblUsername.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/avatar.png")));
    }

    public String getMyDownloadFolder() {
        return this.mydownloadfolder;
    }

    public String getMyUsername() {
        return main.getMyUsername();
    }

    /*
        Hiển thị Message
     */
    public void appendMessage(String msg, String header, Color headerColor, Color contentColor) {
        txtShowMessage.setEditable(true);
        getMsgHeader(header, headerColor);
        getMsgContent(msg, contentColor);
        txtShowMessage.setEditable(false);
    }

    /*
        Tin nhắn chatappendMyMessage
     */
    public void appendMyMessage(String msg, String header) {
        txtShowMessage.setEditable(true);
        getMsgHeader(header, Color.GREEN);
        getMsgContent(msg, Color.GRAY);
        txtShowMessage.setEditable(false);
    }

    /*
        Tiêu đề tin nhắn
     */
    public void getMsgHeader(String header, Color color) {
        int len = txtShowMessage.getDocument().getLength();
        txtShowMessage.setCaretPosition(len);
        txtShowMessage.setCharacterAttributes(MessageStyle.styleMessageContent(color, "Arial", 13), false);
        txtShowMessage.replaceSelection(header + ":   ");
    }

    /*
        Nội dung tin nhắn
     */
    public void getMsgContent(String msg, Color color) {
        int len = txtShowMessage.getDocument().getLength();
        txtShowMessage.setCaretPosition(len);
        txtShowMessage.setCharacterAttributes(MessageStyle.styleMessageContent(color, "Arial", 12), false);
        txtShowMessage.replaceSelection(msg + "\n\n");
    }

    /*  Hàm này sẽ nhận Filename */
    public String getThisFilename(String path) {
        File p = new File(path);
        String fname = p.getName();
        return fname.replace(" ", "_");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblUsername = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtShowMessage = new javax.swing.JTextPane();
        txtMessage = new javax.swing.JTextField();
        btnSend = new javax.swing.JButton();
        btnFilePath = new javax.swing.JButton();
        progressBar = new javax.swing.JProgressBar();
        btnSendFile = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();

        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setResizable(false);

        lblUsername.setBackground(new java.awt.Color(0, 51, 204));
        lblUsername.setText("User");

        txtShowMessage.setEditable(false);
        jScrollPane1.setViewportView(txtShowMessage);

        txtMessage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMessageActionPerformed(evt);
            }
        });

        btnSend.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/send 16x16.png"))); // NOI18N
        btnSend.setText("SEND");
        btnSend.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSendActionPerformed(evt);
            }
        });

        btnFilePath.setText("...");
        btnFilePath.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFilePathActionPerformed(evt);
            }
        });

        progressBar.setStringPainted(true);

        btnSendFile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/Attachement.png"))); // NOI18N
        btnSendFile.setText("Send File");
        btnSendFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSendFileActionPerformed(evt);
            }
        });

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/folder.png"))); // NOI18N
        jMenu1.setText("File");

        jMenuItem1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/loggoff.png"))); // NOI18N
        jMenuItem1.setText("Close");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(txtMessage, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnFilePath, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSendFile)
                .addGap(2, 2, 2)
                .addComponent(btnSend))
            .addGroup(layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(lblUsername, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, 406, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblUsername, javax.swing.GroupLayout.DEFAULT_SIZE, 22, Short.MAX_VALUE)
                    .addComponent(progressBar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 291, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtMessage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnSend)
                        .addComponent(btnSendFile))
                    .addComponent(btnFilePath, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    void sendMessage() {
        try {
            String content = txtMessage.getText();
            Message message = new Message(0, main.client.iD, this.client.iD, content);
            main.sendMessageChat(message.convertToJson());
            appendMyMessage(" " + txtMessage.getText(), "Me");
            txtMessage.setText("");
        } catch (JsonProcessingException e) {
        }
    }

    void openFolder() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int open = chooser.showDialog(this, "Open Folder...");
        if (open == JFileChooser.APPROVE_OPTION) {
            mydownloadfolder = chooser.getSelectedFile().toString() + "\\";
        } else {
            mydownloadfolder = "D:\\";
        }
    }

    void receiveTransferFiles(TransferFile transfer) {
        synchronized (this) {
            int confirm = JOptionPane.showConfirmDialog(this, "Form user: " + main.getUsernameByID(transfer.idSender) + "\nFile name: " + transfer.filename + "\nAre you accpeted file.?");
            if (confirm == 0) { // client chấp nhận yêu cầu, sau đó thông báo đến sender để gửi file
                /* chọn chỗ lưu file   */
                openFolder();
                try {
                    /*  hàm này sẽ tạo một socket filesharing  để tạo một luồng xử lý file đi vào và socket này sẽ tự động đóng khi hoàn thành.  */
                    Socket fSoc = new Socket(main.getMyHost(), main.getMyPort());
                    DataOutputStream fdos = new DataOutputStream(fSoc.getOutputStream());
                    DataInputStream fdis = new DataInputStream(fSoc.getInputStream());
                    /////
                    ////// Gửi public key
                    int lenght = fdis.readInt();
                    byte[] publickey = new byte[lenght];
                    fdis.read(publickey);

                    this.publicKey = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(publickey));

                    //Gửi aeskey
                    AsymmetricCryptography ac = new AsymmetricCryptography();
                    fdos.writeUTF(ac.encryptText(main.aesKey, this.publicKey));

                    String content = MessageType.createsendfilesocket.toString() + " " + transfer.idReceiver + " " + transfer.idSender;
                    fdos.writeUTF(AESEncryption.encryptTextUsingAES(content, main.aesKey));

                    new Thread(new ReceivingFileThread(fSoc, this)).start();

                    Thread.sleep(1000);

                    /*  Run Thread for this   */
                    ///
                    // Format:  CMD_SEND_FILE_ACCEPT [ToSender] [Message]
                    String format = MessageType.sendfileaccept.toString() + " " + transfer.idSender + " " + transfer.idReceiver + " Chấp nhận";
                    
                    dos = new DataOutputStream(main.socket.getOutputStream());
                    dos.writeUTF(AESEncryption.encryptTextUsingAES(format, main.aesKey));

                } catch (IOException e) {
                    System.out.println("[IOException]: " + e.getMessage());
                } catch (Exception ex) {
                    System.out.println("[Exception]: " + ex.getMessage());
                }
            } else { // client từ chối yêu cầu, sau đó gửi kết quả tới sender
                try {
                    dos = new DataOutputStream(socket.getOutputStream());
                    // Format:  CMD_SEND_FILE_ERROR [ToSender] [Message]
                    String format = MessageType.sendfileerror.toString() + " " + transfer.idSender + " " + transfer.idReceiver + " Người dùng từ chối yêu cầu của bạn hoặc bị mất kết nối.!";
                    dos.writeUTF(AESEncryption.encryptTextUsingAES(format, main.aesKey));
                } catch (IOException e) {
                    System.out.println("[IOException]: " + e.getMessage());
                } catch (Exception ex) {
                    System.out.println("[Exception]: " + ex.getMessage());
                }
            }
        }
    }

    public void showOpenDialog() {
        JFileChooser chooser = new JFileChooser();
        int intval = chooser.showOpenDialog(this);
        if (intval == JFileChooser.APPROVE_OPTION) {
            pathFile = chooser.getSelectedFile().toString();
            btnSendFile.setEnabled(true);
        } else {
            pathFile = "";
            btnSendFile.setEnabled(false);
        }
    }

    /*   Phương thức này sẽ disable/enabled tất cả GUI   */
    public void disableGUI(boolean d) {
        if (d) { // Disable
            btnFilePath.setEnabled(false);
            btnSendFile.setEnabled(false);
            progressBar.setVisible(true);
        } else { // Enable
            btnSendFile.setEnabled(false);
            btnFilePath.setEnabled(true);
            progressBar.setVisible(false);
        }
    }

    /*  Nhận Form Title   */
    public void setMyTitle(String s) {
        setTitle(s);
    }

    /*   Hàm này sẽ đóng Form  */
    protected void closeThis() {
        disableGUI(false);
    }
    /**
     * Update progress bar
     *
     * @param val
     */
    public void updateProgress(int val) {
        progressBar.setVisible(true);
        progressBar.setValue(val);
    }

    private void btnSendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSendActionPerformed
        // TODO add your handling code here:
        sendMessage();
    }//GEN-LAST:event_btnSendActionPerformed

    private void txtMessageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMessageActionPerformed
        // TODO add your handling code here:
        sendMessage();
    }//GEN-LAST:event_txtMessageActionPerformed

    private void btnFilePathActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFilePathActionPerformed
        // TODO add your handling code here:
        showOpenDialog();
    }//GEN-LAST:event_btnFilePathActionPerformed

    private void btnSendFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSendFileActionPerformed
        // TODO add your handling code here:
        if (createSocketTransferFile()) {
            try {
                // Format: CMD_SEND_FILE_XD [sender] [receiver] [filename]
                String fname = getThisFilename(pathFile);

                TransferFile sendfileStruct = new TransferFile(main.client.iD, client.iD, fname);

                String content = sendfileStruct.convertToJson();

                String format = MessageType.sendfilexd + " " + content;

                dos.writeUTF(AESEncryption.encryptTextUsingAES(format, main.aesKey));
                
                btnSendFile.setEnabled(false);
            } catch (IOException e) {
                System.out.println(e.getMessage());
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
        }
    }//GEN-LAST:event_btnSendFileActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // TODO add your handling code here:
        setVisible(false);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Chat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Chat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Chat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Chat.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Chat().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFilePath;
    private javax.swing.JButton btnSend;
    private javax.swing.JButton btnSendFile;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblUsername;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JTextField txtMessage;
    private javax.swing.JTextPane txtShowMessage;
    // End of variables declaration//GEN-END:variables
}
