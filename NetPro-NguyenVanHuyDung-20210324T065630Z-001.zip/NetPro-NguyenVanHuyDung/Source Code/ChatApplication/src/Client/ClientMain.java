/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client;

import Utility.Client;
import Utility.Encrytion.AESEncryption;
import Utility.Message;
import Utility.MessageStyle;
import Utility.MessageType;
import Utility.OnlineListRenderer;
import Utility.TransferFile;
import java.awt.Color;
import java.awt.Toolkit;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

/**
 *
 * @author VTB
 */
public final class ClientMain extends javax.swing.JFrame {

    Client client;
    String host;
    int port;
    Socket socket;
    DataOutputStream dos;
    DataInputStream dis;
    public List<Client> listClient;
    String aesKey;
    List<Chat> listchat = new ArrayList<>();
    

    /**
     * Creates new form ClientMain
     */
    public ClientMain() {
        initComponents();
        seticon();
    }

    void seticon() {
        this.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("userchat.png")));
    }
    
    public ClientMain(Client client, String host, int port, Socket socket, String aesKey) throws Exception {
        initComponents();
        seticon();
       
        this.socket = socket;
        dos = new DataOutputStream(socket.getOutputStream());
        dis = new DataInputStream(socket.getInputStream());
        initFrame(client, host, port, aesKey);
    }

    private void initFrame(Client client, String host, int port, String aesKey)  {
        this.host = host;
        this.client = client;
        this.port = port;
        this.aesKey = aesKey;
        setTitle("You are logged in as: " + this.client.userName);
        jLabel2.setText("Username: " + this.client.userName);
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/avatar.png")));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/avatar1.png")));
        
        new Thread(new ClientThread(socket, this)).start();
        listClient = new ArrayList<>();
    }

    
    public String getUserNameByID(int iD) {
        for (Client cli : listClient) {
            if (cli.iD == iD) {
                return cli.userName;
            }
        }
        return null;
    }

    public Client getClientByID(int iD) {
        for (Client cli : listClient) {
            if (cli.iD == iD) {
                return cli;
            }
        }
        return null;
    }
    
    public String getUsernameByID(int iD){
        for (Client client1 : listClient) {
            if (client1.iD == iD) {
                return client1.userName;
            }
        }
        return null;
    }

    /*
        Hiển thị Message
     */
    public void appendMessage(String msg, String header, Color headerColor, Color contentColor) {
        txtShowMessage.setEditable(true);
        getMsgHeader(header, headerColor);
        getMsgContent(msg, contentColor);
        txtShowMessage.setEditable(false);
    }

    /*
        Tin nhắn chatappendMyMessage
     */
    public void appendMyMessage(String msg, String header) {
        txtShowMessage.setEditable(true);
        getMsgHeader(header, Color.ORANGE);
        getMsgContent(msg, Color.LIGHT_GRAY);
        txtShowMessage.setEditable(false);
    }

    /*
        Tiêu đề tin nhắn
     */
    public void getMsgHeader(String header, Color color) {
        int len = txtShowMessage.getDocument().getLength();
        txtShowMessage.setCaretPosition(len);
        txtShowMessage.setCharacterAttributes(MessageStyle.styleMessageContent(color, "Arial", 13), false);
        txtShowMessage.replaceSelection(header + ":   ");
    }

    /*
        Nội dung tin nhắn
     */
    public void getMsgContent(String msg, Color color) {
        int len = txtShowMessage.getDocument().getLength();
        txtShowMessage.setCaretPosition(len);
        txtShowMessage.setCharacterAttributes(MessageStyle.styleMessageContent(color, "Arial", 12), false);
        txtShowMessage.replaceSelection(msg + "\n\n");
    }

    /*
      ************************************  Show Online Sample  *********************************************
     */
    public void showOnlineList() {
        if (isChangeList) {
            DefaultListModel model = new DefaultListModel();
            model.removeAllElements();
            for (Client cli : this.listClient) {
                if (cli.iD != this.client.iD) {
                    model.addElement(cli);
                }
            }
            jListOnline.setModel(model);
            jListOnline.setCellRenderer(new OnlineListRenderer(jListOnline));
            jListOnline.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
            isChangeList = false;
        }
    }
    
    /*
        Phương thức get host
     */
    public String getMyHost() {
        return this.host;
    }

    /*
        Phương thức get Port
     */
    public int getMyPort() {
        return this.port;
    }

    /*
        Phương thức nhận My Username
     */
    public String getMyUsername() {
        return this.client.userName;
    }
    
     private void sendMessage()  {
        try {
            //String content = username + " " + txtMessage.getText();
            String content = txtMessage.getText();
            Message message = new Message(0, this.client.iD, 0, content);
            dos.writeUTF(AESEncryption.encryptTextUsingAES(MessageType.chatall.toString() + " " + message.convertToJson(), aesKey)); //content);
            appendMyMessage(" " + txtMessage.getText(), "Me");
            txtMessage.setText("");
        } catch (IOException ex) {
            appendMessage(" Không thể gửi tin nhắn đi bây giờ, không thể kết nối đến Máy Chủ tại thời điểm này, xin vui lòng thử lại sau hoặc khởi động lại ứng dụng này.!", "Lỗi", Color.RED, Color.RED);
            System.out.println(ex.getMessage());
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void sendMessageChat(String json) {
        try {
            //dos.writeUTF(MessageType.chat.toString() + " " + json);
            dos.writeUTF(AESEncryption.encryptTextUsingAES(MessageType.chat.toString() + " " + json, aesKey));
        } catch (IOException ex) {
            appendMessage(" Không thể gửi tin nhắn đi bây giờ, không thể kết nối đến Máy Chủ tại thời điểm này, xin vui lòng thử lại sau hoặc khởi động lại ứng dụng này.!", "Lỗi", Color.RED, Color.RED);
            System.out.println(ex.getMessage());
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
    
    Chat checkChatForm(Client cli) {
        for (Chat chat : listchat) {
            if (chat.client.iD == cli.iD) {
                return chat;
            }
        }
        return null;
    }

    void addChatForm(Client cli) {
        if (listchat.isEmpty()) {
            Chat chat = new Chat(cli, this.socket, this);
            chat.setVisible(true);
            listchat.add(chat);
        } else {
            Chat chatfrm = checkChatForm(cli);
            if (chatfrm != null) {
                chatfrm.setVisible(true);
            } else {
                Chat chat = new Chat(cli, this.socket, this);
                chat.setVisible(true);
                listchat.add(chat);
            }
        }
    }

    void addChatFormWithMessage(Client cli, String content) {
        if (listchat.isEmpty()) {
            Chat chat = new Chat(cli, this.socket, this);
            chat.setVisible(true);
            chat.appendMessage(content, cli.userName, Color.MAGENTA, Color.BLUE);
            listchat.add(chat);
        } else {
            Chat chatfrm = checkChatForm(cli);
            if (chatfrm != null) {
                chatfrm.setVisible(true);
                chatfrm.appendMessage(content, cli.userName, Color.MAGENTA, Color.BLUE);
            } else {
                Chat chat = new Chat(cli, this.socket, this);
                chat.setVisible(true);
                chat.appendMessage(content, cli.userName, Color.MAGENTA, Color.BLUE);
                listchat.add(chat);
            }
        }
    }
    
    void addChatFormFileTransfer(Client cli, TransferFile transferFile)  {
        if (listchat.isEmpty()) {
            Chat chat = new Chat(cli, this.socket, this);
            chat.setVisible(true);
            chat.receiveTransferFiles(transferFile);
            listchat.add(chat);
        } else {
            Chat chatfrm = checkChatForm(cli);
            if (chatfrm != null) {
                chatfrm.setVisible(true);
                chatfrm.receiveTransferFiles(transferFile);
            } else {
                Chat chat = new Chat(cli, this.socket, this);
                chat.setVisible(true);
                chat.receiveTransferFiles(transferFile);
                listchat.add(chat);
            }
        }
    }

    boolean isChangeList = true;

    private void compareClient(Client inList, Client client) {
        if (!inList.status.equals(client.status)) {
            isChangeList = true;
            inList.status = client.status;
        }
    }

    public void compareClientList(List<Client> list) {
        if (this.listClient.isEmpty()) {
            listClient = list;
            isChangeList = true;
        } else {
            for (int i = 0; i < list.size(); i++) {
                compareClient(this.listClient.get(i), list.get(i));
            }
        }

    }
    //////////////////////////////
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtShowMessage = new javax.swing.JTextPane();
        txtMessage = new javax.swing.JTextField();
        btnSendMessage = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jListOnline = new javax.swing.JList<>();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        btnLogout = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setResizable(false);

        jLabel1.setBackground(new java.awt.Color(204, 204, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Contact");
        jLabel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel1.setOpaque(true);

        txtShowMessage.setEditable(false);
        jScrollPane2.setViewportView(txtShowMessage);

        txtMessage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMessageActionPerformed(evt);
            }
        });

        btnSendMessage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/send 16x16.png"))); // NOI18N
        btnSendMessage.setText("Send");
        btnSendMessage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSendMessageActionPerformed(evt);
            }
        });

        jLabel2.setBackground(new java.awt.Color(204, 204, 204));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Username");
        jLabel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel2.setOpaque(true);

        jListOnline.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jListOnlineMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jListOnline);

        jMenu1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/folder.png"))); // NOI18N
        jMenu1.setText("File");

        btnLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/loggoff.png"))); // NOI18N
        btnLogout.setText("Logout");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });
        jMenu1.add(btnLogout);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 204, Short.MAX_VALUE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 204, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(txtMessage, javax.swing.GroupLayout.DEFAULT_SIZE, 290, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnSendMessage))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 288, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtMessage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSendMessage)))
                    .addComponent(jScrollPane3)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

   

    private void btnSendMessageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSendMessageActionPerformed
        try {
            // TODO add your handling code here:
            sendMessage();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }//GEN-LAST:event_btnSendMessageActionPerformed

    private void txtMessageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMessageActionPerformed
        try {
            // TODO add your handling code here:
            sendMessage();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }//GEN-LAST:event_txtMessageActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        // TODO add your handling code here:
        int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?");
        if (confirm == 0) {
            try {
                socket.close();
            } catch (IOException e) {
                System.exit(0);
                setVisible(false);
                System.out.println(e.getMessage());
            }
        }
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void jListOnlineMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jListOnlineMouseClicked
        // TODO add your handling code here:
        synchronized (this) {
            if (evt.getClickCount() == 2) {
                // Double-click detected
                Object obj = jListOnline.getSelectedValue();
                Client cli = (Client) obj;
                for (int i = 0; i < listClient.size(); i++) {
                    if (listClient.get(i).iD == cli.iD) {
                        addChatForm(listClient.get(i));
                        break;
                    }
                }
            }
        }
    }//GEN-LAST:event_jListOnlineMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ClientMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ClientMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ClientMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ClientMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new ClientMain().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem btnLogout;
    private javax.swing.JButton btnSendMessage;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JList<String> jListOnline;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField txtMessage;
    private javax.swing.JTextPane txtShowMessage;
    // End of variables declaration//GEN-END:variables
}
