/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Client;

import Sound.AudioPlayer;
import Sound.SoundType;
import Utility.Client;
import Utility.Encrytion.AESEncryption;
import Utility.Message;
import Utility.MessageType;
import Utility.TransferFile;
import java.awt.Color;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.StringTokenizer;

/**
 *
 * @author VTB
 */
public class ClientThread implements Runnable {

    Socket socket;
    DataInputStream dis;
    ClientMain main;
    StringTokenizer st;

    public ClientThread(Socket socket, ClientMain main) {
        this.main = main;
        this.socket = socket;
        try {
            dis = new DataInputStream(socket.getInputStream());
        } catch (IOException e) {
            main.appendMessage("[IOException]: " + e.getMessage(), "Error", Color.RED, Color.RED);
        }
    }

    @Override
    public void run() {
        try {
                while (!Thread.currentThread().isInterrupted()) {
                    //Read encrypt message
                    String encrypt = dis.readUTF();
                    //dencrypt message
                    String data = AESEncryption.decryptTextUsingAES(encrypt, main.aesKey);
                    st = new StringTokenizer(data);
                    /**
                     * Get Message MessageType *
                     */
                    String messtype = st.nextToken();

                    ////////////////////////////////////////////////////
                    MessageType messageType = MessageType.valueOf(messtype);
                    ////////////////////////////////////////////////////
                    
                    /**
                     * Check messageType *
                     */
                    switch (messageType) {
                        case message:
                            synchronized (this) {
                                String type = st.nextToken();
                                String content = "";
                                while (st.hasMoreTokens()) {
                                    content = content + " " + st.nextToken();
                                }
                                if (type.compareTo("0") == 0) {                                    
                                    Message message = Message.convertToOject(content);
                                    String name = main.getUserNameByID(message.sender);
                                    main.appendMessage(message.content, name, Color.MAGENTA, Color.BLUE);
                                    AudioPlayer.play(SoundType.messageall);
                                    
                                } else if (type.compareTo("1") == 0) {
                                    Message message = Message.convertToOject(content);
                                    Client clientssend = main.getClientByID(message.sender);
                                    main.appendMessage("You received message from " + clientssend.userName, "", Color.MAGENTA, Color.BLUE);
                                    main.addChatFormWithMessage(clientssend, message.content);
                                    AudioPlayer.play(SoundType.message);
                                } else
                                {
                                    main.appendMessage("You received message from Server", "", Color.MAGENTA, Color.BLUE);
                                    Message message = Message.convertToOject(content);
                                    Client clientssend = main.getClientByID(message.sender);
                                    //System.out.println(content);
                                    clientssend.iD = message.reciever;
                                    clientssend.userName = "Server";
                                    main.addChatFormWithMessage(clientssend, "Cannot send message!!!");
                                    AudioPlayer.play(SoundType.error);
                                }
                                break;
                            }

                        case listonline:
                            synchronized (this) {
                                String json = st.nextToken();
                                main.compareClientList(Client.convertToListOject(json));
                                main.showOnlineList();
                                break;
                            }
                        case sendfilexd:
                            synchronized (this) {
                                String content = "";
                                while (st.hasMoreTokens()) {
                                    content = content + " " + st.nextToken();
                                }
                                TransferFile transfer = TransferFile.convertToOject(content);
                                Client clientssend = main.getClientByID(transfer.idSender);
                                main.appendMessage("You received a file transfer request from " + clientssend.userName, "", Color.MAGENTA, Color.BLUE);
                                AudioPlayer.play(SoundType.transferfile);
                                main.addChatFormFileTransfer(clientssend, transfer);
                                break;
                            }
                        default:
                            main.appendMessage("[MessageTypeException]: Error MessageType " + messageType, "MessageTypeException", Color.RED, Color.RED);
                            break;
                    }
                }
            
        } catch (IOException e) {
            main.appendMessage(" Lost Connection to Server.!", "Error", Color.RED, Color.RED);
            try {
                socket.close();
            } catch (IOException ex) {
                main.appendMessage("[IOException]: " + ex.getMessage(), "Error", Color.RED, Color.RED);
            }
        } catch (Exception ex) {
            main.appendMessage("[Exception]: " + ex.getMessage(), "Error", Color.RED, Color.RED);            
        }
    }
}
