package Client;

import Utility.Encrytion.AESEncryption;
import Utility.MessageType;
import Utility.TransferFile;
import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import javax.swing.JOptionPane;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author VTB
 */
public class SendingFileThread implements Runnable {

    protected Socket socket;
    private DataOutputStream dos;
    
    protected Chat main;
    protected String file;
    protected String receiver;
    protected String sender;
    protected int iDreceiver;
    protected int iDsender;

    private final int BUFFER_SIZE = 2048;


    public SendingFileThread(Socket soc, String file, int iDreceiver, int iDsender, Chat main) {
        this.socket = soc;
        this.file = file;
        this.iDreceiver = iDreceiver;
        this.iDsender = iDsender;
        this.main = main;
    }
    

    @Override
    public void run() {
        try {
            main.disableGUI(true);
            dos = new DataOutputStream(socket.getOutputStream());
            /**
             * Write filename, recipient, username  *
             */
            File filename = new File(file);
            int len = (int) filename.length();
            int filesize = (int) Math.ceil(len / BUFFER_SIZE); // phương thức nhận kích thước file
           
            TransferFile transfer = new TransferFile(iDsender, iDreceiver, filename.getName(), filesize);
            
            String format = MessageType.sendfile.toString() + " " + transfer.convertToJson();
            dos.writeUTF(AESEncryption.encryptTextUsingAES(format, main.main.aesKey));
            
            /**
             * Create an stream *
             */
            InputStream input = new FileInputStream(filename);
            OutputStream output = socket.getOutputStream();
            /*  Các tiến trình trên màn hình  */

            // Đọc file 
            BufferedInputStream bis = new BufferedInputStream(input);
            /**
             * Tạo một chỗ để chứa file *
             */
            byte[] buffer = new byte[BUFFER_SIZE];
            int count, percent = 0;
            while ((count = bis.read(buffer)) > 0) {
                percent = percent + count;
                //int p = (percent / filesize);
                int p = (percent / filesize) / (2048 / 100);
                main.updateProgress(p);
                output.write(buffer, 0, count);
            }
            /* Cập nhật AttachmentForm GUI */
            main.setMyTitle("File send successfully!");
            JOptionPane.showMessageDialog(main, "File send successfully.!", "File send Successful!!!", JOptionPane.INFORMATION_MESSAGE);
            main.closeThis();
            /* Đóng gửi file */
            output.flush();
            output.close();
            main.disableGUI(false);
            socket.close();
        } catch (IOException e) {
            System.out.println("[SendFile]: " + e.getMessage());
        } catch (Exception ex) {
            System.out.println("[SendFile]: " + ex.getMessage());
        }
    }
}
