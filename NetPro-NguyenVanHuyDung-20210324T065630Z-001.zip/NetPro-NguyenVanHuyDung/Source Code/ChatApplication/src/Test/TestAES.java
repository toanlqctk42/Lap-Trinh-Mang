/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import Utility.Encrytion.AESEncryption;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

/**
 *
 * @author VTB
 */
public class TestAES {

    public static void main(String[] args) throws Exception {
        
        //final String secretKey = "ssshhhhhhhhhhh!!!!";

        String originalString = "howtodoinjava.com";
        String key = AESEncryption.getSecretAESKeyAsString();
        String encryptedString = AESEncryption.encryptTextUsingAES(originalString, key);
        String decryptedString = AESEncryption.decryptTextUsingAES(encryptedString, key);

        System.out.println(originalString);
        System.out.println(encryptedString);
        System.out.println(decryptedString);
        
    }
}
