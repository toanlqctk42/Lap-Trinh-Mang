/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import Utility.Client;
import Utility.ClientStatus;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author VTB
 */
public class AddClientList {

    public static void main(String[] args) throws IOException {
        List<Client> listclient = new ArrayList<>();
        listclient.add(new Client(1, "dung", "123", ClientStatus.offline));
        listclient.add(new Client(2, "nguyen", "123", ClientStatus.offline));
        listclient.add(new Client(3, "nhan", "123", ClientStatus.offline));
        listclient.add(new Client(4, "test", "123", ClientStatus.offline));
        listclient.add(new Client(5, "vtb", "123", ClientStatus.offline));
        listclient.add(new Client(6, "cuong", "123", ClientStatus.offline));
        listclient.add(new Client(7, "emrys", "123", ClientStatus.offline));
        listclient.add(new Client(8, "merlin", "123", ClientStatus.offline));
        listclient.add(new Client(9, "sang", "123", ClientStatus.offline));
        listclient.add(new Client(10, "bao", "123", ClientStatus.offline));
        
        Client.writeToFile(listclient);
        
        //System.out.println(Client.convertListToJson(listclient)); 

        //List<Client> listclient = new ArrayList<>();
        
        //listclient = Client.readFormFileToObject1();
        
        //Client t =  Client.readFormFileToObject1();
        
        //System.out.println(t.userName);
        
//{"iD":0,"userName":"vtb","password":"123","status":"offline"}
    //String json = "{\"iD\":0,\"userName\":\"vtb\",\"password\":\"123\",\"status\":\"offline\"}";
    
        
    }
}
