/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Sound;

import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 *
 * @author VTB
 * http://www.codejava.net/coding/how-to-play-back-audio-in-java-with-examples
 */
public class AudioPlayer {

    /**
     * this flag indicates whether the playback completes or not.
     */
    boolean playCompleted;

    /**
     * Play a given audio file.
     *
     * @param type
     * @param audioFilePath Path of the audio file.
     */
    public static void play(SoundType type) {
        File audioFile = null;
        Clip clip;
        switch (type) {
            case message:
                audioFile = new File("audio/skype_sms.wav");
                break;
            case transferfile:
                audioFile = new File("audio/transfer_file.wav");
                break;
            case messageall:
                audioFile = new File("audio/messageall.wav");
                break;
            case error:
                audioFile = new File("audio/error.wav");
                break;
        }

        try {
            //File file = new File("audio/transfer_file.wav");
            AudioInputStream audioIS = AudioSystem.getAudioInputStream(audioFile);

            clip = AudioSystem.getClip();
            clip.open(audioIS);
            clip.setFramePosition(0);
            clip.start();
            //clip.stop();
        } catch (IOException | LineUnavailableException | UnsupportedAudioFileException e) {
            System.out.println(e.getMessage());
        }

    }

}
